from pathlib import Path
import difflib
w=Path(__file__).parent
changes={}
name='arch/x86/include/asm/kvm_host.h';before=(w/'pf29-source'/name).read_text()
needle='\tu32 pending_write;\n\tstruct mutex lock;'
assert before.count(needle)==1
after=before.replace(needle,'\tu32 pending_write;\n\t/* 页锁保护的固定截止时间，快速路径不得续期。 */\n\tu64 write_grant_until_ns;\n\tstruct mutex lock;')
changes[name]=(before,after)
name='arch/x86/kvm/ivy.c';before=(w/'pf29-source'/name).read_text();after=before
needle='#include <linux/mmu_context.h>\n'
assert after.count(needle)==1
after=after.replace(needle,needle+'#include <linux/moduleparam.h>\n#include <linux/hrtimer.h>\n')
needle='static char *req_desc[3] = { "INV", "READ", "WRITE" };\n'
addition='''
/* 独占实验开关；关闭时保持原协议，显式拒绝超过一毫秒的配置。 */
static unsigned int dsm_write_grace_us;

static int dsm_set_write_grace(const char *value, const struct kernel_param *param)
{
	unsigned int duration;
	int ret = kstrtouint(value, 0, &duration);

	if (ret)
		return ret;
	if (duration > 1000)
		return -EINVAL;
	WRITE_ONCE(*(unsigned int *)param->arg, duration);
	return 0;
}

static const struct kernel_param_ops dsm_write_grace_ops = {
	.set = dsm_set_write_grace,
	.get = param_get_uint,
};
module_param_cb(dsm_write_grace_us, &dsm_write_grace_ops, &dsm_write_grace_us, 0644);
MODULE_PARM_DESC(dsm_write_grace_us, "实验写授权保留微秒数：0 关闭，最大 1000");

static u64 dsm_write_grant_remaining(struct kvm *kvm,
				   struct kvm_dsm_memory_slot *slot, hfn_t vfn)
{
	u64 now, until;

	if (!READ_ONCE(dsm_write_grace_us) || READ_ONCE(kvm->arch.dsm_stopped) ||
	    !dsm_is_owner(slot, vfn) || !dsm_is_modified(slot, vfn))
		return 0;
	until = slot->vfn_dsm_state[vfn - slot->base_vfn].write_grant_until_ns;
	now = ktime_get_ns();
	return until > now ? until - now : 0;
}
'''
assert after.count(needle)==1;after=after.replace(needle,needle+addition)
needle='\tbool retry = false, active_request = false;\n'
assert after.count(needle)==1;after=after.replace(needle,needle+'\tu64 grant_delay_ns = 0;\n')
needle='\n\t\tswitch (req.req_type) {\n'
assert after.count(needle)==1
after=after.replace(needle,'''
		/* 固定期限内先保留写授权；不交所有权，不触碰副本集合。 */
		if (req.req_type == DSM_REQ_READ || req.req_type == DSM_REQ_WRITE) {
			grant_delay_ns = dsm_write_grant_remaining(kvm, slot, vfn);
			if (grant_delay_ns) {
				retry = true;
				goto retry_unlock;
			}
		}
'''+needle)
needle='\t\t/* 固定页面触发重试时尚未交出所有权，必须保留现有副本集合。 */'
assert after.count(needle)==1;after=after.replace(needle,'retry_unlock:\n'+needle)
needle='''		if (retry) {
			retry = false;
			schedule();
			goto retry_handle_req;
		}'''
assert after.count(needle)==1
after=after.replace(needle,'''		if (retry) {
			retry = false;
			/* 页锁和 SRCU 已释放；每段最多等一百微秒，信号可立即打断。 */
			if (grant_delay_ns) {
				ktime_t delay = ns_to_ktime(min_t(u64, grant_delay_ns, 100000));

				set_current_state(TASK_INTERRUPTIBLE);
				schedule_hrtimeout(&delay, HRTIMER_MODE_REL);
				grant_delay_ns = 0;
			} else {
				schedule();
			}
			goto retry_handle_req;
		}''')
needle='out:\n\thandle_end = ktime_get();'
assert after.count(needle)==1
after=after.replace(needle,'''out:
	/* 仅新授予独占写权限时设置一次；已有可写映射的快速路径不续期。 */
	if (write && (ret & ACC_WRITE_MASK)) {
		unsigned int duration = READ_ONCE(dsm_write_grace_us);

		slot->vfn_dsm_state[vfn - slot->base_vfn].write_grant_until_ns =
			duration ? ktime_get_ns() + (u64)duration * 1000 : 0;
	}
	handle_end = ktime_get();''')
changes[name]=(before,after)
patch=''
for name,(before,after) in changes.items():
 path=w/'pf30-source'/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_text(after)
 patch+=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+name,tofile='b/'+name))
(w/'kernel-write-grace-candidate.patch').write_text(patch)
print(patch)
