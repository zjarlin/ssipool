from pathlib import Path
import subprocess,hashlib,json
w=Path(__file__).parent;base=['limactl','shell','sshpool','--'];root='/home/zjarlin.guest/ssi-build/kernel';out='/home/zjarlin.guest/ssi-build/kernel-out'
expected=json.loads((w.parent/'steal-time/compiled-source-hashes.json').read_text())
actual=subprocess.check_output(base+['sha256sum',*[root+'/'+f for f in expected]],text=True)
assert [line.split()[0] for line in actual.splitlines()]==list(expected.values())
assert subprocess.check_output(base+['cat',out+'/.config'])==(w/'config-pf29').read_bytes()
for name in ['arch/x86/include/asm/kvm_host.h','arch/x86/kvm/ivy.c']:
 assert subprocess.check_output(base+['cat',root+'/'+name])==(w/'pf29-source'/name).read_bytes()
 value=(w/'pf30-source'/name).read_bytes()
 subprocess.run(base+['tee',root+'/'+name],input=value,stdout=subprocess.DEVNULL,check=True)
 expected[name]=hashlib.sha256(value).hexdigest()
(w/'compiled-source-hashes-pf30.json').write_text(json.dumps(expected,indent=2)+'\n')
subprocess.run(base+[root+'/scripts/config','--file',out+'/.config','--set-str','LOCALVERSION','-sshpool-gvm-pf30'],check=True)
make=['make','-C',root,'O='+out,'ARCH=x86_64','CROSS_COMPILE=x86_64-linux-gnu-']
with (w/'build-pf30.log').open('xb') as log:
 subprocess.run(base+make+['olddefconfig'],check=True,stdout=log,stderr=subprocess.STDOUT)
 subprocess.run(base+make+['-j2','bzImage','modules'],check=True,stdout=log,stderr=subprocess.STDOUT)
config=subprocess.check_output(base+['cat',out+'/.config']);(w/'config-pf30').write_bytes(config)
assert (w/'config-pf29').read_text().replace('-sshpool-gvm-pf29','-sshpool-gvm-pf30')==config.decode()
print('PF30 experimental kernel compiled',flush=True)
