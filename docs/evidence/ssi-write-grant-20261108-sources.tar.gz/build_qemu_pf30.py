from pathlib import Path
import subprocess,json,hashlib,difflib
w=Path(__file__).parent;prior=w.parent/'steal-time';ssh=['ssh','-F',str(w/'guest_ssh_config'),'-o','BatchMode=yes','-o','ConnectTimeout=8'];remote='/home/ubuntu/ssi/qemu'
def read(n,cmd,timeout=60):return subprocess.check_output(ssh+[f'ssi-lab-{n+1}',cmd],timeout=timeout)
for n in (0,1):
 assert read(n,'uname -r; cat /etc/machine-id').decode().splitlines()==['7.1.0-rc3-sshpool-gvm-pf30',['bed141ceb5a94840930beead90b4d3a8','97609053a4db470a8a9fd24d2d2af76b'][n]]
 assert not [s for s in read(n,'ps -eo comm=').decode().splitlines() if s.startswith(('qemu-system-','probe-grant','grant-reader','kvm-dsm/','dsm-conn/'))]
 assert int(read(n,'df -B1 --output=avail / | tail -1'))>100*1024*1024
 assert int(read(n,'df -B1 --output=avail /dev/shm | tail -1'))>160*1024*1024
hashes=json.loads((prior/'qemu-pf29-build.json').read_text())['compiled_source_sha256']
for name,digest in hashes.items():assert read(0,'sha256sum '+remote+'/'+name).decode().split()[0]==digest
name='system/ssi-close.inc';before=read(0,'cat '+remote+'/'+name);(w/'qemu-close-pf29.inc').write_bytes(before)
after=before.replace(b'PF29',b'PF30').replace(b'7.1.0-rc3-sshpool-gvm-pf29',b'7.1.0-rc3-sshpool-gvm-pf30');assert before!=after
(w/'qemu-close-pf30.inc').write_bytes(after)
patch=''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='a/'+name,tofile='b/'+name));(w/'qemu-pf30-profile.patch').write_text(patch)
subprocess.run(ssh+['ssi-lab-1','cat > '+remote+'/'+name],input=after,check=True)
hashes[name]=hashlib.sha256(after).hexdigest()
binary='qemu-system-x86_64-pf30-grace-1';target='/dev/shm/'+binary;link='/home/ubuntu/ssi/'+binary
original=read(0,'cat '+remote+'/build/build.ninja')
needle=b'build qemu-system-x86_64: c_LINKER_RSP '
assert original.count(needle)==1
redirected=original.replace(needle,('build '+target+': c_LINKER_RSP ').encode())
(w/'qemu-build.ninja-before').write_bytes(original)
(w/'qemu-build.ninja-pf30').write_bytes(redirected)
subprocess.run(ssh+['ssi-lab-1','test ! -e '+remote+'/build/build-pf30-grace.ninja && cat > '+remote+'/build/build-pf30-grace.ninja'],input=redirected,check=True)
with (w/'qemu-pf30-build.log').open('xb') as log:subprocess.run(ssh+['ssi-lab-1','ninja -C '+remote+'/build -f build-pf30-grace.ninja -j2 '+target],stdout=log,stderr=subprocess.STDOUT,check=True)
assert read(0,'cat '+remote+'/build/build.ninja')==original
subprocess.run(ssh+['ssi-lab-1',f'test -x {target} && test ! -e {link} && ln -s {target} {link}'],check=True)
with (w/binary).open('xb') as f:subprocess.run(ssh+['ssi-lab-1','cat '+target],stdout=f,check=True)
digest=hashlib.sha256((w/binary).read_bytes()).hexdigest()
subprocess.run(ssh+['ssi-lab-2',f'test ! -e {target} && test ! -e {link} && cat > {target} && chmod 755 {target} && ln -s {target} {link}'],input=(w/binary).read_bytes(),check=True)
for n in (0,1):
 assert read(n,'sha256sum '+link).decode().split()[0]==digest
 assert read(n,link+' --version').decode().startswith('QEMU emulator version 10.1.2')
 assert read(n,'sha256sum /home/ubuntu/ssi/qemu-system-x86_64-pf29-close-1').decode().split()[0]=='d51d81986ecdcbfb5f1889d02480028cc4bf5f4466d3d09fcf34c653940ff251'
 assert int(read(n,'df -B1 --output=avail / | tail -1'))>64*1024*1024
for name,expected in hashes.items():assert read(0,'sha256sum '+remote+'/'+name).decode().split()[0]==expected
(w/'qemu-pf30-build.json').write_text(json.dumps({'binary':binary,'sha256':digest,'size':(w/binary).stat().st_size,'compiled_source_sha256':hashes,'patch_sha256':hashlib.sha256(patch.encode()).hexdigest(),'prior_binary_preserved_on_both_nodes':True,'tmpfs_binary_on_both_nodes':True},indent=2)+'\n')
print('PF30 QEMU built and hashes verified',digest,flush=True)
