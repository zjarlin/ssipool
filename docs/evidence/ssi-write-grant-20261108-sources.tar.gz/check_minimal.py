from pathlib import Path
from collections import Counter
import importlib.util,json,re,sys
spec=importlib.util.spec_from_file_location('guest','/Users/zjarlin/projects/sshpool/scripts/ssi-lab/check-guest-timers.py');guest=importlib.util.module_from_spec(spec);spec.loader.exec_module(guest)
demand=guest.demand

def inspect(data):
 demand(not data['errors'],'harness errors')
 demand(data['firewall_before']==data['firewall_after'],'firewall changed')
 count=2 if data['mode']=='pair' else 1
 demand(set(data['traces'])=={str(n) for n in range(count)},'trace nodes incomplete')
 result={}
 generations=[]
 for node in range(count):
  log=[row['record'] for row in data['events'] if row['node']==node]
  ready=log[0];pid=ready['pid'];demand(ready['op']=='ready' and ready['node']==node and ready['nodes']==count,'ready identity')
  demand(log[-1]=={'op':'closed'},'worker not closed')
  seals=[row['generation'] for row in log if row['op']=='sealed'];demand(len(seals)==1 and seals[0]>0,'close not sealed');generations+=seals
  writes=[row for row in log if row['op']=='write'];demand(len(writes)==(320 if count==2 else 64),'write count mismatch')
  first=1 if node==0 else 321
  demand([row['value'] for row in writes]==list(range(first,first+len(writes))),'write IDs mismatch')
  demand(all(row['observed']==row['value'] and row['exit_reason']==5 and row['rip']==4101 and row['elapsed_ns']>=0 for row in writes),'store not completed')
  if count==2:
   stopped=[row for row in log if row['op']=='reader_stopped'];demand(len(stopped)==1 and stopped[0]['reads']>0 and stopped[0]['regressions']==0,'reader failed')
   demand([row['value'] for row in log if row['op']=='read']==[320,640],'peer final data mismatch')
  capture=data['traces'][str(node)];before,after=capture['before'],capture['after']
  demand(before['pid']==pid and before['comm']=='probe-grant' and before['kernel'] in ('7.1.0-rc3-sshpool-gvm-pf29','7.1.0-rc3-sshpool-gvm-pf30'),'capture identity')
  for stat in (before['stat'],after['stat']):demand(stat.split(' ',1)[0]==str(pid),'stat PID')
  demand(before['stat'].rsplit(')',1)[1].split()[19]==after['stat'].rsplit(')',1)[1].split()[19],'PID reused')
  demand(after['cleanup_complete'] and '[global]' in before['trace_clock'].split(),'cleanup or clock')
  demand(before['filter'].strip()==f'common_pid == {pid}' and before['format'].startswith('name: kvm_page_fault\n'),'event filter')
  rows=[]
  for line in after['trace'].splitlines():
   if not line.strip() or line.startswith('#'):continue
   match=guest.native.drain.safety.teardown.EVENT.fullmatch(line);demand(match is not None,'trace format')
   comm,tid,cpu,stamp,name,detail=match.groups();sec,part=stamp.split('.')
   demand(int(tid)==pid and comm.strip()=='probe-grant','trace process identity')
   demand(name in ('kvm_page_fault','tracing_mark_write'),'unknown event')
   rows.append({'index':len(rows),'cpu':int(cpu),'ns':int(sec)*1000000000+int(part.ljust(9,'0')),'name':name,'detail':detail})
  demand(re.findall(r'entries-in-buffer/entries-written: (\d+)/(\d+)',after['trace'])==[(str(len(rows)),str(len(rows)))],'trace count mismatch')
  demand(all(a['ns']<=b['ns'] for a,b in zip(rows,rows[1:])),'trace time reversed')
  demand(set(after['stats'])=={'cpu0','cpu1'},'CPU stats missing')
  counts=Counter(row['cpu'] for row in rows)
  for cpu,stats in after['stats'].items():
   demand(re.findall(r'^entries: (\d+)$',stats,re.M)==[str(counts[int(cpu[3:])])],'CPU count mismatch')
   for key in ('overrun','commit overrun','dropped events'):
    demand(re.findall('^'+key+r': (\d+)$',stats,re.M)==['0'],'trace loss')
  calls=[];active=None
  for row in rows:
   if row['name']=='tracing_mark_write':
    match=re.fullmatch(r'grant_(begin|end) value=(\d+)',row['detail']);demand(match is not None,'unknown marker')
    value=int(match[2])
    if match[1]=='begin':
     demand(active is None,'overlapping calls');active={'value':value,'begin':row,'faults':[]}
    else:
     demand(active is not None and active['value']==value,'unmatched call')
     active.update(end=row,span_ns=row['ns']-active['begin']['ns']);calls.append(active);active=None
   else:
    demand(active is not None,'fault outside run')
    match=re.fullmatch(r'vcpu (\d+) rip (0x[0-9a-f]+) address (0x[0-9a-f]+) error_code (0x[0-9a-f]+)',row['detail']);demand(match is not None,'fault fields')
    vcpu=int(match[1]);rip,address,error=(int(match[i],16) for i in (2,3,4))
    demand(vcpu==node and rip in (0x1000,0x1004) and address in (0x1000,0x2000),'fault outside fixed guest')
    if address==0x2000:
     demand(rip==0x1000 and error&2,'not the sole write instruction');active['faults'].append(row)
  demand(active is None and [row['value'] for row in calls]==[row['value'] for row in writes],'run boundaries mismatch')
  result[str(node)]={'writes':len(calls),'store_faults':sum(len(row['faults']) for row in calls),
   'repeated_stores':sum(len(row['faults'])>1 for row in calls),'max_faults_per_store':max(len(row['faults']) for row in calls),
   'max_run_ns':max(row['elapsed_ns'] for row in writes),'longest_fault_sequences':sorted(calls,key=lambda row:-len(row['faults']))[:10]}
 demand(len(set(generations))==1,'close generation mismatch')
 return result
if __name__=='__main__':
 path=Path(sys.argv[1]);result=inspect(json.loads(path.read_text()));path.with_suffix('.analysis.json').write_text(json.dumps(result,indent=2)+'\n')
 for node,data in result.items():print(node,{k:v for k,v in data.items() if k!='longest_fault_sequences'})
