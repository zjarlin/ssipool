from pathlib import Path
import subprocess,time,json,hashlib
work=Path(__file__).parent;baseline=work.parent;lab=baseline.parent
nodes=json.loads((work/'boot.json').read_text())
base=['ssh','-F',str(work/'guest_ssh_config'),'-o','BatchMode=yes','-o','ConnectTimeout=4']
def read(row,address,command,timeout=30):
 return subprocess.check_output(base+['-o','HostName='+address,f'ssi-lab-{row["node"]+1}',command],timeout=timeout,stderr=subprocess.PIPE).decode()
def check(row,address):
 assert read(row,address,'cat /etc/machine-id').strip()==row['machine_id']
 names=read(row,address,'ps -eo comm=').splitlines()
 assert not [x for x in names if x.strip().startswith(('qemu-system-','probe-grant','grant-reader','kvm-dsm/','dsm-conn/','memfd:sshpool','kvm-nx-lpage-'))]
 assert not read(row,address,'sudo cat /sys/kernel/tracing/kprobe_events; sudo find /sys/kernel/tracing/instances -mindepth 1 -maxdepth 1').strip()
 assert json.loads(read(row,address,'sudo nft -j -a list chain inet sshpool_ssi_lab input'))==json.loads((baseline/f'node{row["node"]}-before-firewall.json').read_text())
 ports=' or '.join(f'{side} = :{port}' for side in ('sport','dport') for port in (37710,37711,40000,40001,22230))
 assert not read(row,address,f"ss -H -tan '( {ports} )'").strip()
records=[]
for row in nodes:
 n=row['node'];address=row['address'];check(row,address)
 assert read(row,address,'uname -r').strip()==row['kernel']
 assert read(row,address,'sudo cat /boot/grub/grub.cfg')==(work/f'node{n}-grub.cfg').read_text()
 assert not read(row,address,'sudo grub-editenv /boot/grub/grubenv list').strip()
 assert read(row,address,'cat /sys/module/kvm/parameters/dsm_write_grace_us').strip()=='0'
 link='/home/ubuntu/ssi/qemu-system-x86_64-pf30-grace-1'
 target=read(row,address,f'if test -L {link}; then readlink {link}; fi').strip()
 if target:
  assert target=='/dev/shm/qemu-system-x86_64-pf30-grace-1'
  read(row,address,f'rm {link}')
 read(row,address,'sudo systemctl reboot')
 print('stock reboot requested',n,flush=True)
 deadline=time.monotonic()+300
 while time.monotonic()<deadline:
  try:
   actual=read(row,row['stock'],'uname -r; cat /etc/machine-id',timeout=8).splitlines()
   if actual==['6.8.0-147-generic',row['machine_id']]:break
  except (subprocess.CalledProcessError,subprocess.TimeoutExpired):pass
  time.sleep(3)
 else:raise RuntimeError('stock observation expired; do not reset')
 address=row['stock'];check(row,address)
 entry=read(row,address,'sudo cat /etc/grub.d/42_sshpool_pf30_grace')
 assert entry==(work/f'node{n}-entry').read_text()
 (work/f'node{n}-removed-pf30-entry').write_text(entry)
 prior_entry=read(row,address,'sudo cat /etc/grub.d/41_sshpool_pf29_steal')
 assert prior_entry==(baseline/f'node{n}-entry').read_text()
 (work/f'node{n}-removed-pf29-entry').write_text(prior_entry)
 read(row,address,'sudo rm /etc/grub.d/42_sshpool_pf30_grace /etc/grub.d/41_sshpool_pf29_steal && sudo update-grub',timeout=60)
 cfg=read(row,address,'sudo cat /boot/grub/grub.cfg');assert cfg==(baseline/f'node{n}-before-grub.cfg').read_text()
 assert 'set default="Advanced options for Ubuntu>Ubuntu, with Linux 6.8.0-147-generic"' in cfg
 assert read(row,address,'readlink /lib').strip()=='usr/lib'
 assert not read(row,address,'sudo grub-editenv /boot/grub/grubenv list').strip()
 hashes=read(row,address,'sudo sha256sum /boot/*generic /boot/*pf*',timeout=60)
 assert hashes==(baseline/f'node{n}-before-boot.sha256').read_text()
 record={'node':n,'kernel':actual[0],'identity_matches':True,'old_boot_files_unchanged':True,'boot_hash_manifest_sha256':hashlib.sha256(hashes.encode()).hexdigest(),'grub_config_unchanged':True,'firewall_matches_original':True,'lib_target':'usr/lib','grub_environment':'','remaining_processes':[],'remaining_trace_instances':[],'remaining_experiment_tcp':[],'stock_grub_default':True,'pf29_grub_entry_removed':True,'pf30_grub_entry_removed':True,'write_grace_reset_before_reboot':True,'pf29_boot_artifacts_preserved':True}
 records.append(record)
 (work/'restoration.json').write_text(json.dumps({'nodes':records},indent=2)+'\n')
 print('stock identity, hashes, firewall and cleanup verified',n,flush=True)
