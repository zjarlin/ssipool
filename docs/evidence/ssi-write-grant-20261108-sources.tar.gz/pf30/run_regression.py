from pathlib import Path
import subprocess,time,json,sys
w=Path(__file__).parent;lab=w.parent.parent
base=['ssh','-F',str(w/'guest_ssh_config'),'-o','BatchMode=yes','-o','ConnectTimeout=8']
peers=json.loads((w/'boot.json').read_text())
ports=' or '.join(f'{side} = :{port}' for side in ('sport','dport') for port in (37710,37711,40000,40001,22230))
chain='sudo nft -j -a list chain inet sshpool_ssi_lab input'
comment='sshpool-pf28-workspace'
def read(node,command):
 return subprocess.check_output(base+[f'ssi-lab-{node+1}',command],timeout=30).decode()
def idle(node):
 assert read(node,'cat /etc/machine-id').strip()==['bed141ceb5a94840930beead90b4d3a8','97609053a4db470a8a9fd24d2d2af76b'][node]
 assert read(node,'uname -r').strip()==peers[node]['kernel']
 names=read(node,'ps -eo comm=').splitlines()
 assert not [x for x in names if x.strip().startswith(('qemu-system-','memfd:sshpool','kvm-dsm/','dsm-conn/'))]
 assert not read(node,'sudo cat /sys/kernel/tracing/kprobe_events; sudo find /sys/kernel/tracing/instances -mindepth 1 -maxdepth 1').strip()
 deadline=time.monotonic()+180
 while read(node,f"ss -H -tan '( {ports} )'").strip():
  if time.monotonic()>deadline:raise RuntimeError('TCP states not drained')
  time.sleep(2)
 assert int(read(node,'df -B1 --output=avail / | tail -1').strip())>=64*1024*1024
mode=sys.argv[1];label=sys.argv[2];grace=int(sys.argv[3]);assert mode in ('control','pair') and grace in (0,1000)
qemu=json.loads((w.parent/'qemu-pf30-build.json').read_text())
parameter='/sys/module/kvm/parameters/dsm_write_grace_us'
for mode in (mode,):
 for node in (0,1):idle(node)
 before=[json.loads(read(n,chain)) for n in (0,1)]
 assert all(before[n]==json.loads((w/f'node{n}-before-firewall.json').read_text()) for n in (0,1))
 active=[]
 assert all(read(n,'cat '+parameter).strip()=='0' for n in (0,1))
 try:
  for node in (0,1):
   subprocess.run(base+[f'ssi-lab-{node+1}','sudo tee '+parameter+' >/dev/null'],input=str(grace).encode(),check=True,timeout=15)
   assert read(node,'cat '+parameter).strip()==str(grace)
  if mode=='pair':
   for node in (0,1):
    peer=peers[1-node]['address']
    rule=f'insert rule inet sshpool_ssi_lab input ip saddr {peer} tcp dport {{ 37710, 37711, 40000, 40001 }} accept comment "{comment}"\n'
    subprocess.run(base+[f'ssi-lab-{node+1}','sudo nft -f -'],input=rule.encode(),check=True,timeout=15)
  active=[json.loads(read(n,chain)) for n in (0,1)]
  args=['python3','-u',str(w/'run_workspace.py'),'--mode',mode,'--variant','sync','--label',label,'--kernel',peers[0]['kernel'],'--qemu',qemu['binary'],'--qemu-sha',qemu['sha256']]
  subprocess.run(args,check=True)
  r=json.loads((lab/'evidence'/f'{label}-result.json').read_text())
  assert not r.get('management_timeout') and not r.get('host_log_timeout'),r
  assert all(x is not None for x in r['qemu_ssh_exits']),r
 finally:
  for node in (0,1):
   current=json.loads(read(node,chain))
   for value in current['nftables']:
    rule=value.get('rule',{})
    if rule.get('comment')==comment:
     subprocess.run(base+[f'ssi-lab-{node+1}',f'sudo nft delete rule inet sshpool_ssi_lab input handle {rule["handle"]}'],check=True,timeout=15)
  for node in (0,1):
   subprocess.run(base+[f'ssi-lab-{node+1}','sudo tee '+parameter+' >/dev/null'],input=b'0',check=True,timeout=15)
   assert read(node,'cat '+parameter).strip()=='0'
  after=[json.loads(read(n,chain)) for n in (0,1)]
  assert before==after
  (w/(label+'-firewall.json')).write_text(json.dumps({'before':before,'active':active,'after':after,'restored_exactly':True,'write_grace_us':grace,'write_grace_restored':True},indent=2)+'\n')
 for node in (0,1):idle(node)
 print('workspace processes, trace, TCP and firewall clean',mode,flush=True)
