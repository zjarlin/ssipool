import argparse
from pathlib import Path
import hashlib
import json
import subprocess
import shlex
import threading
import select
import time

parser=argparse.ArgumentParser()
parser.add_argument('--mode',choices=['control','pair'],required=True)
parser.add_argument('--variant',choices=['baseline','adjust','sync'],required=True)
parser.add_argument('--label',required=True)
parser.add_argument('--kernel',choices=['7.1.0-rc3-sshpool-gvm-pf30'],required=True)
parser.add_argument('--qemu')
parser.add_argument('--qemu-sha')
args=parser.parse_args()
if bool(args.qemu)!=bool(args.qemu_sha): raise SystemExit('both qemu and qemu-sha required')
root=Path('/Users/zjarlin/.sshpool/ssi-lab')
prefix=root/'evidence'/args.label
if Path(str(prefix)+'-result.json').exists():
    raise SystemExit('Refusing to overwrite prior run')
config=Path(__file__).parent/'guest_ssh_config'
base=['ssh','-F',str(config),'-o','BatchMode=yes','-o','ConnectTimeout=30','-o','ServerAliveInterval=15','-o','ServerAliveCountMax=3']
peers=[r['address'] for r in json.loads((Path(__file__).parent/'boot.json').read_text())]
nodes=range(2 if args.mode=='pair' else 1)
stop=threading.Event()
logs=[]
processes=[]
close_tracers=[]
results={'mode':args.mode,'variant':args.variant,'phases':{},'samples_errors':[]}
qemu_name='qemu-system-x86_64-clock-offset-1' if args.variant=='sync' else 'qemu-system-x86_64-unpin'
if args.qemu: qemu_name=args.qemu
expected_machines=['bed141ceb5a94840930beead90b4d3a8','97609053a4db470a8a9fd24d2d2af76b']
host_cursors={}
results['qemu']=qemu_name
results['qemu_sha256']=args.qemu_sha
started=time.monotonic()
def phase(name, command, timeout=180, stdin=None):
    captures=[]
    print(f'phase={name} start elapsed={time.monotonic()-started:.1f}',flush=True)
    begin=time.monotonic()
    with open(str(prefix)+'-'+name+'.log','wb') as out:
        try:
            result=subprocess.run(command,input=stdin,stdout=out,stderr=subprocess.STDOUT,timeout=timeout)
            code=result.returncode
        except subprocess.TimeoutExpired:
            code=124
            out.write(b'\nHARNESS_TIMEOUT\n')
    phase_seconds=round(time.monotonic()-begin,3)
    for node,kind,tracer,err,remote_output in captures:
        tracer.stdin.write('stop\n');tracer.stdin.flush()
    for node,kind,tracer,err,remote_output in captures:
        status=tracer.wait(timeout=45);err.close()
        raw=subprocess.check_output(base+[f'ssi-lab-{node+1}','sudo cat '+remote_output],timeout=60)
        Path(f'{prefix}-node{node}-{kind}-trace.json').write_bytes(raw)
        if status:raise RuntimeError(f'trace node {node} kind {kind} exited {status}')
    results['phases'][name]={'exit':code,'seconds':phase_seconds}
    print(f'phase={name} exit={code} elapsed={time.monotonic()-started:.1f}',flush=True)
    return code

def sample():
    while not stop.is_set():
        for node in nodes:
            try:
                result=subprocess.run(base+[f'ssi-lab-{node+1}','date -u +%FT%TZ; ps -eLo pid,tid,comm,time,stat | grep "CPU .*/KVM" || true; free -m'],capture_output=True,timeout=40)
                with open(f'{prefix}-node{node}-samples.log','ab') as out:
                    out.write(result.stdout+result.stderr)
                if result.returncode:
                    results['samples_errors'].append({'node':node,'exit':result.returncode})
            except subprocess.TimeoutExpired:
                results['samples_errors'].append({'node':node,'exit':124})
        stop.wait(20)

def start_close_trace():
    if args.mode != 'pair':
        return
    for node in nodes:
        listing=subprocess.check_output(base+[f'ssi-lab-{node+1}', 'ps -eo pid=,comm='],text=True)
        pids=[int(line.split()[0]) for line in listing.splitlines() if line.split()[1].startswith('qemu-system-')]
        assert len(pids)==1,pids
        remote='/home/ubuntu/ssi/qemu-close-trace/'+args.label+f'-node{node}.json'
        error=Path(f'{prefix}-node{node}-close-trace-stderr.log').open('x')
        command=['sudo','python3','/home/ubuntu/ssi/qemu-close-trace/trace-kernel-close.py','--pid',str(pids[0]),'--node',str(node),'--output',remote]
        proc=subprocess.Popen(base+[f'ssi-lab-{node+1}',shlex.join(command)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=error,text=True)
        close_tracers.append((node,proc,error,remote))
        assert select.select([proc.stdout],[],[],15)[0],'close tracer readiness timeout'
        reply=json.loads(proc.stdout.readline());assert reply['ready'] and reply['pid']==pids[0]
    print('native close tracers ready on both nodes',flush=True)

for node in nodes:
    guard=subprocess.run(base+[f'ssi-lab-{node+1}','cat /etc/machine-id'],capture_output=True,timeout=40,check=True)
    if guard.stdout.decode().strip()!=expected_machines[node]:
        raise SystemExit('Lab ownership guard failed')
    command='test "$(uname -r)" = 7.1.0-rc3-sshpool-gvm-pf5 && test -z "$(pgrep -x qemu-system-x86 || true)" && sha256sum /var/lib/sshpool/boot-pf30/vmlinuz-7.1.0-rc3-sshpool-gvm-pf5 ~/ssi/qemu-system-x86_64-unpin ~/ssi/guest-vmlinuz ~/ssi/guest-ssh-ubuntu-initramfs.cpio.gz ~/ssi/run-clock-node.sh'
    cursor=subprocess.run(base+[f'ssi-lab-{node+1}','sudo journalctl -k -b -n 0 --show-cursor --no-pager'],capture_output=True,timeout=40,check=True)
    host_cursors[node]=cursor.stdout.decode().split('-- cursor: ',1)[1].strip()
    Path(f'{prefix}-node{node}-start-cursor.txt').write_text(host_cursors[node]+'\n')
    command='test -z "$(ss -H -tan \"( sport = :37710 or sport = :37711 or sport = :40000 or sport = :40001 or dport = :37710 or dport = :37711 or dport = :40000 or dport = :40001 )\")" && '+command
    command=command.replace('qemu-system-x86_64-unpin',qemu_name).replace('7.1.0-rc3-sshpool-gvm-pf5',args.kernel)
    result=subprocess.run(base+[f'ssi-lab-{node+1}',command],capture_output=True,timeout=40,check=True)
    Path(f'{prefix}-node{node}-hashes.txt').write_bytes(result.stdout)
    expected=[json.loads((Path(__file__).parent.parent/'pf30-build-hashes.json').read_text())['kernel'],
              args.qemu_sha,
              '41ba36d860aa0b0cd995f4ca8856d80249b244577e704929b55be13fbd1ebd2f',
              '87342480b6393c24c82aa72125ffb328ff5b9c32e4af24116365a37fb87e9861',
              'ae6f0cc156d6ee1da62f4b6b76a5ff34cb7d8d14e5128ba7538fe73f00f58c0f']
    if args.qemu_sha: expected[1]=args.qemu_sha
    if [line.split()[0] for line in result.stdout.decode().splitlines()]!=expected:
        raise SystemExit('Runtime hash mismatch')
for node in nodes:
    if args.mode=='pair':
        runner='run-clock-node.sh' if args.variant in ('adjust','sync') else 'run-node.sh'
        command=f'SSHPOOL_LAB_GLOBAL_CLOSE=1 QEMU=$HOME/ssi/{qemu_name} INITRAMFS=$HOME/ssi/guest-ssh-ubuntu-initramfs.cpio.gz SSH_PORT=22230 RUN_SECONDS=1800 bash ~/ssi/{runner} {node} {peers[0]} {peers[1]}'
    else:
        cpu='qemu64,-x2apic,+tsc-adjust,enforce' if args.variant in ('adjust','sync') else 'qemu64,-x2apic'
        smp='4,sockets=2,cores=2,threads=1' if args.variant in ('adjust','sync') else '4'
        command=f'exec timeout --kill-after=5 1800 ~/ssi/{qemu_name} -name sshpool-clock-control,debug-threads=on -machine pc,accel=kvm,kernel-irqchip=split -cpu {cpu} -smp {smp} -m 256 -nodefaults -display none -serial stdio -monitor none -no-reboot -L ~/ssi/pc-bios -kernel ~/ssi/guest-vmlinuz -initrd ~/ssi/guest-ssh-ubuntu-initramfs.cpio.gz -netdev user,id=sshpool,restrict=on,hostfwd=tcp:127.0.0.1:22230-:22 -device virtio-net-pci,disable-modern=on,vectors=0,netdev=sshpool,mac=52:54:00:53:53:01 -append "console=ttyS0 rdinit=/init nokaslr panic=10 nox2apic"'
    log=open(f'{prefix}-node{node}-qemu.log','wb')
    logs.append(log)
    err=open(f'{prefix}-node{node}-qemu-stderr.log','wb')
    logs.append(err)
    processes.append(subprocess.Popen(base+[f'ssi-lab-{node+1}','ulimit -c 0; '+command],stdout=log,stderr=err))
sampler=threading.Thread(target=sample,daemon=True)
sampler.start()
print('guest started',flush=True)
try:
    while time.monotonic()-started<800:
        serial=Path(f'{prefix}-node0-qemu.log').read_text(errors='replace')
        if 'Server listening on 0.0.0.0 port 22.' in serial:
            break
        if any(p.poll() is not None for p in processes):
            raise RuntimeError('QEMU exited during boot')
        time.sleep(3)
    else:
        raise RuntimeError('Boot readiness timeout')
    phase('identity',base+['ssi-guest','hostname; uname -r; nproc; mount; cat /sys/devices/system/clocksource/clocksource0/current_clocksource; cat /sys/devices/system/clocksource/clocksource0/available_clocksource; cat /proc/cpuinfo'],180)
    batch=f'put /Users/zjarlin/projects/sshpool/scripts/ssi-lab/trace-guest-timers.sh /tmp/ssi-timer-trace.sh\nput {Path(__file__).parent}/guest-clock-intervals /tmp/ssi-clock\nchmod 700 /tmp/ssi-clock\nput {root}/guest-pause /tmp/ssi-pause\nchmod 700 /tmp/ssi-pause\n'
    code=phase('clock-upload',['sftp','-F',str(config),'-o','ConnectTimeout=45','-o','ServerAliveInterval=15','-o','ServerAliveCountMax=3','-b','-','ssi-guest'],180,batch.encode())
    if code==0:
        ready=phase('guest-trace-start',base+['ssi-guest','sh /tmp/ssi-timer-trace.sh start writer'],60)
        if ready:raise RuntimeError('guest trace start failed')
        phase('clock',base+['ssi-guest',"for trial in 1 2 3 4 5 6; do sh -c 'echo TRACE_CLOCK_PID=$$; exec /tmp/ssi-clock --timer-intervals' || exit $?; done"],300)
        stopped=phase('guest-trace-stop',base+['ssi-guest','sh /tmp/ssi-timer-trace.sh stop'],120)
        if stopped:raise RuntimeError('guest trace stop failed')
        with Path(f'{prefix}-guest-timer-trace.tar.gz').open('xb') as capture:
            subprocess.run(base+['ssi-guest','tar -czf - -C /tmp/ssi-timer-capture .'],stdout=capture,check=True,timeout=120)
        print('guest timer trace retrieved',flush=True)
    phase('stress',base+['ssi-guest','/bin/ssi-proof'],480)
    phase('pause-user',base+['ssi-guest','/tmp/ssi-pause'],90)
    target=root/f'sftp-{args.label}-return.bin'
    batch=f'put {root}/sftp-input.bin /tmp/ssi-transfer.bin\nget /tmp/ssi-transfer.bin {target}\nrm /tmp/ssi-transfer.bin\n'
    code=phase('sftp',['sftp','-F',str(config),'-o','ConnectTimeout=45','-o','ServerAliveInterval=15','-o','ServerAliveCountMax=3','-b','-','ssi-guest'],300,batch.encode())
    results['sftp_matches']=code==0 and target.read_bytes()==(root/'sftp-input.bin').read_bytes()
    if results['sftp_matches']:
        results['sftp_sha256']=hashlib.sha256(target.read_bytes()).hexdigest()
    phase('poweroff',base+['ssi-guest','poweroff -f'],90)
except Exception as error:
    results['harness_error']=str(error)
    print(f'harness_error={error}',flush=True)
    phase('failure-poweroff',base+['ssi-guest','poweroff -f'],90)
finally:
    for process in processes:
        try:
            process.wait(timeout=max(1,1850-(time.monotonic()-started)))
        except subprocess.TimeoutExpired:
            results['management_timeout']=True
    stop.set()
    sampler.join(timeout=45)
    for log in logs: log.close()
    for node,proc,error,remote in close_tracers:
        if proc.poll() is None:
            proc.stdin.write('stop\n');proc.stdin.flush()
    for node,proc,error,remote in close_tracers:
        code=proc.wait(timeout=30);error.close()
        raw=subprocess.check_output(base+[f'ssi-lab-{node+1}','sudo cat '+remote],timeout=30)
        Path(f'{prefix}-node{node}-close-trace.json').write_bytes(raw)
        results.setdefault('close_trace_exits',[]).append(code)
    results['qemu_ssh_exits']=[p.poll() for p in processes]
    results['seconds']=round(time.monotonic()-started,2)
    for node in nodes:
        try:
            result=subprocess.run(base+[f'ssi-lab-{node+1}','sudo journalctl -k -b --no-pager --after-cursor='+shlex.quote(host_cursors[node])+'; ps -eLo pid,tid,comm,stat | grep -E "qemu|kvm-dsm|dsm-conn" || true'],capture_output=True,timeout=40)
            Path(f'{prefix}-node{node}-host.log').write_bytes(result.stdout+result.stderr)
        except subprocess.TimeoutExpired:
            results['host_log_timeout']=True
    Path(str(prefix)+'-result.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps(results,indent=2),flush=True)
