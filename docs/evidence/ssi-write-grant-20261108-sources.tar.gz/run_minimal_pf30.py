from pathlib import Path
import asyncio,json,subprocess,shlex,time,hashlib,sys
work=Path(__file__).parent;lab=work.parent
mode=sys.argv[1];label=sys.argv[2];assert mode in ('control','pair')
grace=int(sys.argv[3]);assert grace in (0,100,500,1000)
count=2 if mode=='pair' else 1
nodes=json.loads((work/'pf30/boot.json').read_text())
ssh=['ssh','-F',str(work/'guest_ssh_config'),'-o','BatchMode=yes','-o','ConnectTimeout=8','-o','ServerAliveInterval=10','-o','ServerAliveCountMax=3']
ports=' or '.join(f'{side} = :{port}' for side in ('sport','dport') for port in (37710,37711,40000,40001))
result={'mode':mode,'label':label,'events':[],'traces':{},'errors':[]};chain='sudo nft -j -a list chain inet sshpool_ssi_lab input';comment='sshpool-grant-progress'
def command(node,text,**kwargs):return subprocess.check_output(ssh+[f'ssi-lab-{node+1}',text],timeout=30,**kwargs)
def idle(node):
 assert command(node,'cat /etc/machine-id').decode().strip()==nodes[node]['machine_id']
 assert command(node,'uname -r').decode().strip()==nodes[node]['kernel']
 names=command(node,'ps -eo comm=').decode().splitlines()
 assert not [s for s in names if s.strip().startswith(('qemu-system-','probe-grant','grant-reader','kvm-dsm/','dsm-conn/','memfd:sshpool'))]
 assert not command(node,'sudo cat /sys/kernel/tracing/kprobe_events; sudo find /sys/kernel/tracing/instances -mindepth 1 -maxdepth 1').strip()
 deadline=time.monotonic()+180
 while command(node,f"ss -H -tan '( {ports} )'").strip():
  if time.monotonic()>deadline:raise RuntimeError('TCP did not drain')
  time.sleep(2)
def trace(node,action,pid):
 raw=command(node,f'sudo python3 - {action} {pid}',input=(work/'trace_minimal_pf30.py').read_bytes())
 return json.loads(raw)
class Worker:
 def __init__(self,node,process):self.node=node;self.process=process;self.active=False;self.pid=None
 async def receive(self):
  line=await asyncio.wait_for(self.process.stdout.readline(),60)
  if not line:raise RuntimeError(f'node {self.node} EOF')
  row=json.loads(line);result['events'].append({'node':self.node,'record':row})
  return row
 async def send(self,text):
  self.process.stdin.write((text+'\n').encode());await self.process.stdin.drain()
 async def expect(self,text,op):
  await self.send(text);row=await self.receive();assert row['op']==op,(text,row);return row
 async def writes(self,amount,base):
  await self.send(f'write {amount} {base}');rows=[]
  for i in range(amount):
   row=await self.receive();assert row['op']=='write' and row['value']==row['observed']==base+i+1 and row['rip']==4101 and row['exit_reason']==5,row
   rows.append(row)
  assert (await self.receive())=={'op':'writes_done'}
  print('writes complete',self.node,amount,'max_ns',max(r['elapsed_ns'] for r in rows),flush=True)
async def run():
 workers=[];logs=[];traced=[]
 try:
  for n in range(count):
   peers=[nodes[i]['address'] for i in range(2)] if count==2 else ['127.0.0.1','-']
   log=(work/f'{label}-node{n}-stderr.log').open('xb');logs.append(log)
   process=await asyncio.create_subprocess_exec(*ssh,f'ssi-lab-{n+1}',shlex.join(['sudo','/home/ubuntu/ssi/probe-grant',str(n),*peers,nodes[n]['kernel']]),stdin=asyncio.subprocess.PIPE,stdout=asyncio.subprocess.PIPE,stderr=log)
   workers.append(Worker(n,process))
  for w in workers:
   ready=await w.receive();assert ready['op']=='ready' and ready['node']==w.node and ready['nodes']==count
   w.pid=ready['pid'];result['traces'][str(w.node)]={'before':trace(w.node,'start',w.pid)};traced.append(w)
   await w.expect('trace','trace_ready')
  value=0
  for writer in workers:
   await writer.writes(64,value);value+=64
   if count==1:continue
   reader=workers[1-writer.node]
   await reader.expect('reader_start','reader_started');reader.active=True
   try:await writer.writes(256,value)
   finally:
    stopped=await reader.expect('reader_stop','reader_stopped');reader.active=False
    assert stopped['reads']>0 and stopped['regressions']==0,stopped
   value+=256
   for w in workers:assert (await w.expect('read','read'))['value']==value
 finally:
  for w in workers:
   if w.active:
    await w.expect('reader_stop','reader_stopped');w.active=False
  for w in traced:
   try:
    await w.expect('untrace','trace_closed')
    result['traces'][str(w.node)]['after']=trace(w.node,'stop',w.pid)
   except Exception as error:result['errors'].append('trace cleanup: '+str(error))
  if workers:
   generation=time.monotonic_ns()
   closed=await asyncio.gather(*(w.expect(f'seal {generation}','sealed') for w in workers),return_exceptions=True)
   for row in closed:
    if isinstance(row,BaseException):result['errors'].append(str(row))
    else:assert row['generation']==generation
   for w in reversed(workers):
    await w.expect('quit','closed')
    status=await asyncio.wait_for(w.process.wait(),60)
    assert status==0,status
  for log in logs:log.close()
for n in (0,1):idle(n)
before=[json.loads(command(n,chain)) for n in (0,1)]
assert all(before[n]==json.loads((work/f'node{n}-before-firewall.json').read_text()) for n in (0,1))
parameter='/sys/module/kvm/parameters/dsm_write_grace_us'
result['grace_before']=[int(command(n,'cat '+parameter)) for n in (0,1)]
assert result['grace_before']==[0,0]
try:
 for n in (0,1):command(n,'sudo tee '+parameter+' >/dev/null',input=str(grace).encode())
 result['grace_active']=[int(command(n,'cat '+parameter)) for n in (0,1)]
 assert result['grace_active']==[grace,grace]
 binary=(work/'probe-grant').read_bytes();expected=hashlib.sha256(binary).hexdigest()
 for n in range(count):
  command(n,'cat > /home/ubuntu/ssi/probe-grant && chmod 755 /home/ubuntu/ssi/probe-grant',input=binary)
  assert command(n,'sha256sum /home/ubuntu/ssi/probe-grant').decode().split()[0]==expected
 if count==2:
  for n in (0,1):
   rule=f'insert rule inet sshpool_ssi_lab input ip saddr {nodes[1-n]["address"]} tcp dport {{ 37710, 37711, 40000, 40001 }} accept comment "{comment}"\n'
   command(n,'sudo nft -f -',input=rule.encode())
 result['firewall_before']=before;result['firewall_active']=[json.loads(command(n,chain)) for n in (0,1)]
 asyncio.run(run())
finally:
 for n in (0,1):
  current=json.loads(command(n,chain))
  for item in current['nftables']:
   rule=item.get('rule',{})
   if rule.get('comment')==comment:command(n,f'sudo nft delete rule inet sshpool_ssi_lab input handle {rule["handle"]}')
 result['firewall_after']=[json.loads(command(n,chain)) for n in (0,1)]
 for n in (0,1):command(n,'sudo tee '+parameter+' >/dev/null',input=b'0')
 result['grace_after']=[int(command(n,'cat '+parameter)) for n in (0,1)]
 assert result['grace_after']==[0,0]
 (work/f'{label}.json').write_text(json.dumps(result,indent=2)+'\n')
assert result['firewall_after']==before
assert not result['errors']
for n in (0,1):idle(n)
print('complete and clean',label,flush=True)
