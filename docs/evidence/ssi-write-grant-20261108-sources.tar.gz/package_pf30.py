from pathlib import Path
import subprocess,json,hashlib
w=Path(__file__).parent;lab=w.parent;base=['limactl','shell','sshpool','--'];build='/home/zjarlin.guest/ssi-build'
expected=json.loads((w/'compiled-source-hashes-pf30.json').read_text())
actual=subprocess.check_output(base+['sha256sum',*[build+'/kernel/'+f for f in expected]],text=True)
assert [line.split()[0] for line in actual.splitlines()]==list(expected.values())
assert subprocess.check_output(base+['cat',build+'/kernel-out/include/config/kernel.release'],text=True).strip()=='7.1.0-rc3-sshpool-gvm-pf30'
script='''set -eu
cd /home/zjarlin.guest/ssi-build
test ! -e kernel-package-pf30
mkdir -p kernel-package-pf30/boot kernel-package-pf30/usr
make -C kernel O="$PWD/kernel-out" ARCH=x86_64 CROSS_COMPILE=x86_64-linux-gnu- INSTALL_MOD_PATH="$PWD/kernel-package-pf30" modules_install
mv kernel-package-pf30/lib kernel-package-pf30/usr/lib
if test -L kernel-package-pf30/usr/lib/modules/7.1.0-rc3-sshpool-gvm-pf30/build; then unlink kernel-package-pf30/usr/lib/modules/7.1.0-rc3-sshpool-gvm-pf30/build; fi
cp kernel-out/arch/x86/boot/bzImage kernel-package-pf30/boot/vmlinuz-7.1.0-rc3-sshpool-gvm-pf30
cp kernel-out/.config kernel-package-pf30/boot/config-7.1.0-rc3-sshpool-gvm-pf30
cp kernel-out/System.map kernel-package-pf30/boot/System.map-7.1.0-rc3-sshpool-gvm-pf30
tar -C kernel-package-pf30 -czf kernel-pf30-runtime.tar.gz boot usr
'''
with (w/'package-pf30.log').open('xb') as log:subprocess.run(base+['bash','-s'],input=script.encode(),stdout=log,stderr=subprocess.STDOUT,check=True)
archive=lab/'sources/kernel-pf30-runtime.tar.gz'
with archive.open('xb') as out:subprocess.run(base+['cat',build+'/kernel-pf30-runtime.tar.gz'],stdout=out,check=True)
kernel=subprocess.check_output(base+['sha256sum',build+'/kernel-out/arch/x86/boot/bzImage'],text=True).split()[0]
report={'kernel':kernel,'archive':hashlib.sha256(archive.read_bytes()).hexdigest(),'compiled_sources':expected,'patch_sha256':hashlib.sha256((w/'kernel-write-grace-candidate.patch').read_bytes()).hexdigest()}
(w/'pf30-build-hashes.json').write_text(json.dumps(report,indent=2)+'\n')
print('PF30 package complete',archive.stat().st_size,flush=True)
