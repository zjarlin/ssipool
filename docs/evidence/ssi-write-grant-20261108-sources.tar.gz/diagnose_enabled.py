from pathlib import Path
import importlib.util,json
repo=Path('/Users/zjarlin/projects/sshpool');s=importlib.util.spec_from_file_location('irq',repo/'scripts/ssi-lab/check-guest-irq.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
w=Path(__file__).parent;raw=w.parent/'evidence';label='pf30-grace-pair-1000-a';files=m.guest.read_archive(raw/(label+'-guest-timer-trace.tar.gz'));log=(raw/(label+'-clock.log')).read_text();rows,marks=m.guest.parse(files,m.capture_events(files));apps=m.guest.application_intervals(log);gens=m.guest.timer_generations(rows);bad=[]
for generation,app in zip(gens,apps):
 start,expire,end=(generation[k] for k in ('start','expire','end'));pid=app['pid'];cpu=app['cpu']
 switches=[r for r in rows[start['index']+1:expire['index']] if r['name']=='sched_switch' and int(m.guest.field(r,'prev_pid'))==pid and m.guest.field(r,'prev_state')=='S']
 if len(switches)!=1 or switches[0]['cpu']!=cpu:
  nearby=[r for r in rows[start['index']:end['index']+1] if r['name'] in ('sched_switch','sched_waking','sched_wakeup') and (str(pid) in r['detail'])]
  bad.append({'application':app,'generation':generation,'sleep_switches':switches,'nearby':nearby})
result={'application_intervals':apps,'max_application_ns':max(a['elapsed_ns'] for a in apps),'failed_sleep_associations':bad,'writer_only':m.inspect_writers(rows,marks,[]),'full_attribution_accepted':False,'failure':'缺少唯一睡眠切换'}
(w/'pf30/enabled-a-attribution-diagnostic.json').write_text(json.dumps(result,indent=2)+'\n')
print('max_timer_ms',result['max_application_ns']/1e6,'writer_only_ms',result['writer_only']['distribution']['max_ns']/1e6,'bad',len(bad))
for b in bad:print(json.dumps(b,indent=2))
