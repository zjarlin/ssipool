from pathlib import Path
import asyncio,hashlib,importlib.util,json,shlex,subprocess,sys,time
work=Path(__file__).parent;repo=Path('/Users/zjarlin/projects/sshpool');prior=work.parent/'atomic-grant-progress'
label,mode,server,source_port,dest_port,local_client=sys.argv[1:];server=int(server);source_port=int(source_port);dest_port=int(dest_port);local_client=local_client=='1';client=server if local_client else 1-server
assert mode in ('legacy','fixed') and not (work/(label+'.json')).exists()
nodes=json.loads((prior/'boot.json').read_text());tag='sshpool-tcp-reply';ports='{ 37710, 37711, 40000, 40001 }'
spec=importlib.util.spec_from_file_location('fw',repo/'scripts/ssi-lab/lab-firewall.py');fw=importlib.util.module_from_spec(spec);spec.loader.exec_module(fw)
def ssh(n):return ['ssh','-F',str(prior/'guest_ssh_config'),'-o','BatchMode=yes','-o','ConnectTimeout=8','-o','ControlMaster=auto','-o','ControlPersist=90','-o','ControlPath='+str(work/f'ssh-{n}.sock'),'-o','HostName='+nodes[n]['stock'],f'ssi-lab-{n+1}']
def command(n,cmd,data=None):return subprocess.check_output(ssh(n)+[cmd],input=data,timeout=30)
def chain(n):return json.loads(command(n,'sudo nft -j -a list chain inet sshpool_ssi_lab input'))
def clean(n):
 assert command(n,'cat /etc/machine-id').decode().strip()==nodes[n]['machine_id']
 assert command(n,'uname -r').decode().strip()=='6.8.0-147-generic'
 assert int(command(n,'df -B1 --output=avail / | tail -1'))>64*1024*1024
 assert not command(n,"ss -H -tan '( sport >= :37710 and sport <= :37773 or dport >= :37710 and dport <= :37773 or sport >= :40000 and sport <= :40063 or dport >= :40000 and dport <= :40063 or sport = :"+str(source_port)+" or dport = :"+str(source_port)+" )'").strip()
 names=command(n,'ps -eo comm=').decode().splitlines();assert not [x for x in names if x.strip().startswith(('probe-grant','qemu-system-','kvm-dsm/','dsm-conn/'))]
 return {'machine_id':nodes[n]['machine_id'],'kernel':'6.8.0-147-generic','address':nodes[n]['stock'],'ephemeral_range':command(n,'cat /proc/sys/net/ipv4/ip_local_port_range').decode(),'reserved_ports':command(n,'cat /proc/sys/net/ipv4/ip_local_reserved_ports').decode()}
result={'label':label,'mode':mode,'server':server,'client':client,'source_port':source_port,'dest_port':dest_port,'events':[],'captures':{},'errors':[]}
result['nodes']=[clean(n) for n in (0,1)];before=[chain(n) for n in (0,1)];result['firewall_before']=before
assert all(before[n]==json.loads((prior/f'node{n}-before-firewall.json').read_text()) for n in (0,1))
for name,source in [('probe-tcp-reply.py',repo/'scripts/ssi-lab/probe-tcp-reply.py'),('tcp-reply-collector.py',work/'collector.py')]:
 raw=source.read_bytes();result.setdefault('source_hashes',{})[name]=hashlib.sha256(raw).hexdigest()
 for n in (0,1):
  remote='/home/ubuntu/ssi/'+name
  digest=command(n,'sha256sum '+remote).decode().split()[0]
  if digest!=result['source_hashes'][name]:command(n,'cat > '+remote,raw)
async def row(proc,node):
 line=await asyncio.wait_for(proc.stdout.readline(),10)
 if not line:raise RuntimeError('EOF node '+str(node)+' '+(await proc.stderr.read()).decode())
 value=json.loads(line);result['events'].append({'node':node,'record':value,'received_ns':time.monotonic_ns()});return value
async def run():
 collectors=[];workers=[]
 try:
  a=nodes[client]['stock'];b=nodes[server]['stock'];fil=f'tcp and host {a} and host {b} and ((src port {source_port} and dst port {dest_port}) or (src port {dest_port} and dst port {source_port}))'
  for n in sorted({server,client}):
   p=await asyncio.create_subprocess_exec(*ssh(n),'sudo python3 /home/ubuntu/ssi/tcp-reply-collector.py '+shlex.quote(fil),stdin=asyncio.subprocess.PIPE,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.PIPE)
   collectors.append((n,p));assert (await row(p,n))['op']=='capture_ready'
  for role,n,local_port,other,other_port in [('server',server,dest_port,client,source_port),('client',client,source_port,server,dest_port)]:
   cmd=shlex.join(['python3','/home/ubuntu/ssi/probe-tcp-reply.py',role,nodes[n]['stock'],str(local_port),nodes[other]['stock'],str(other_port)])
   p=await asyncio.create_subprocess_exec(*ssh(n),cmd,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.PIPE)
   workers.append((n,p));assert (await row(p,n))['op']==('ready' if role=='server' else 'bound')
  for n,p in reversed(workers):
   assert (await row(p,n))['op']=='result'
   status=await asyncio.wait_for(p.wait(),10);assert status==0
   result.setdefault('worker_exits',[]).append({'node':n,'exit':status,'stderr':(await p.stderr.read()).decode()})
 except Exception as error:
  result['errors'].append(type(error).__name__+': '+str(error));raise
 finally:
  for n,p in collectors:
   if p.returncode is None:
    p.stdin.write(b'stop\n');await p.stdin.drain()
    result['captures'][str(n)]=await row(p,n)
   assert await asyncio.wait_for(p.wait(),10)==0
   result['captures'][str(n)]['collector_stderr']=(await p.stderr.read()).decode()
try:
 result['rules']={}
 for n in (0,1):
  peer=nodes[1-n]['stock']
  rule=(f'insert rule inet sshpool_ssi_lab input ip saddr {peer} tcp dport {ports} accept comment "{tag}-request"\n' if mode=='legacy' else fw.rules(peer,tag))
  result['rules'][str(n)]=rule;command(n,'sudo nft -f -',rule.encode())
 a=nodes[client]['stock'];b=nodes[server]['stock'];sources=', '.join(sorted({a,b}))
 for n in sorted({server,client}):
  rule=f'insert rule inet sshpool_ssi_lab input ip saddr {{ {sources} }} ip daddr {nodes[n]["stock"]} tcp sport {{ {source_port}, {dest_port} }} tcp dport {{ {source_port}, {dest_port} }} meta nftrace set 1 comment "{tag}-trace"\n'
  command(n,'sudo nft -f -',rule.encode())
 result['firewall_active']=[chain(n) for n in (0,1)]
 asyncio.run(run())
finally:
 for n in (0,1):
  for item in chain(n)['nftables']:
   rule=item.get('rule',{})
   if rule.get('comment','').startswith(tag+'-'):command(n,f'sudo nft delete rule inet sshpool_ssi_lab input handle {rule["handle"]}')
 result['firewall_after']=[chain(n) for n in (0,1)]
 (work/(label+'.json')).write_text(json.dumps(result,indent=2)+'\n')
assert result['firewall_after']==before and not result['errors']
result['cleanup']=[clean(n) for n in (0,1)]
(work/(label+'.json')).write_text(json.dumps(result,indent=2)+'\n')
print(label,[e['record'] for e in result['events'] if e['record']['op']=='result'],flush=True)
