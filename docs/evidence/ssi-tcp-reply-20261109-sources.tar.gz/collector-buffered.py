import base64,json,os,select,signal,subprocess,sys,tempfile
filter_text=sys.argv[1]
with tempfile.TemporaryDirectory(prefix='sshpool-tcp-reply-') as root:
 pcap=root+'/packets.pcap'
 with open(root+'/nft.jsonl','w+b') as trace,open(root+'/nft.stderr','w+b') as err:
  monitor=subprocess.Popen(['nft','-j','monitor','trace'],stdout=trace,stderr=err)
  capture=subprocess.Popen(['tcpdump','-U','-n','-i','any','-w',pcap,filter_text],stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
  messages=[]
  try:
   while True:
    ready,_,_=select.select([capture.stderr],[],[],5)
    if not ready:raise RuntimeError('tcpdump readiness timeout')
    line=capture.stderr.readline().decode();messages.append(line)
    if not line:raise RuntimeError('tcpdump ended before readiness')
    if 'listening on' in line:break
   assert monitor.poll() is None
   print(json.dumps({'op':'capture_ready','pid':os.getpid(),'tcpdump_pid':capture.pid,'nft_pid':monitor.pid}),flush=True)
   ready,_,_=select.select([sys.stdin],[],[],45)
   if not ready:raise RuntimeError('collector controller timeout')
   assert sys.stdin.readline().strip()=='stop'
  finally:
   capture.send_signal(signal.SIGINT)
   try:_,extra=capture.communicate(timeout=5)
   except subprocess.TimeoutExpired:
    capture.kill();_,extra=capture.communicate();raise
   monitor.terminate()
   try:monitor.wait(timeout=5)
   except subprocess.TimeoutExpired:monitor.kill();monitor.wait();raise
  messages.append(extra.decode());trace.seek(0);err.seek(0)
  packets=subprocess.check_output(['tcpdump','-nn','-tt','-r',pcap],stderr=subprocess.PIPE).decode()
  print(json.dumps({'op':'capture','pcap_base64':base64.b64encode(open(pcap,'rb').read()).decode(),'packets':packets,'tcpdump_stderr':''.join(messages),'tcpdump_exit':capture.returncode,'nft_trace':trace.read().decode(),'nft_stderr':err.read().decode(),'nft_exit':monitor.returncode}),flush=True)
