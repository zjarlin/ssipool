from pathlib import Path
import subprocess,time,json,hashlib
work=Path(__file__).parent;nodes=json.loads((work/'boot.json').read_text());base=['ssh','-F',str(work/'guest_ssh_config'),'-o','BatchMode=yes','-o','ConnectTimeout=5']
def read(row,address,command,timeout=90):
 return subprocess.check_output(base+['-o','HostName='+address,f'ssi-lab-{row["node"]+1}',command],timeout=timeout,stderr=subprocess.PIPE).decode()
def check(row,address):
 assert read(row,address,'cat /etc/machine-id').strip()==row['machine_id']
 names=read(row,address,'ps -eo comm=').splitlines()
 assert not [x for x in names if x.strip().startswith(('qemu-system-','probe-grant','grant-reader','kvm-dsm/','dsm-conn/','memfd:sshpool','kvm-nx-lpage-'))]
 assert not read(row,address,'sudo cat /sys/kernel/tracing/kprobe_events; sudo find /sys/kernel/tracing/instances -mindepth 1 -maxdepth 1').strip()
 assert json.loads(read(row,address,'sudo nft -j -a list chain inet sshpool_ssi_lab input'))==json.loads((work/f'node{row["node"]}-before-firewall.json').read_text())
 ports=' or '.join(f'{side} = :{port}' for side in ('sport','dport') for port in (37710,37711,40000,40001,22230))
 assert not read(row,address,f"ss -H -tan '( {ports} )'").strip()
records=[]
for row in nodes:
 n=row['node'];address=row['address'];check(row,address)
 assert read(row,address,'cat /proc/sys/net/ipv4/ip_local_port_range').split()==['32768','60999']
 assert not read(row,address,'cat /proc/sys/net/ipv4/ip_local_reserved_ports').strip()
 assert read(row,address,'uname -r').strip()==row['kernel']
 assert read(row,address,'sudo cat /boot/grub/grub.cfg')==(work/f'node{n}-grub.cfg').read_text()
 assert not read(row,address,'sudo grub-editenv /boot/grub/grubenv list').strip()
 assert read(row,address,'cat /sys/module/kvm/parameters/dsm_write_grace_us').strip()=='0'
 read(row,address,'sudo systemctl reboot');print('stock reboot requested',n,flush=True)
 deadline=time.monotonic()+300
 while time.monotonic()<deadline:
  try:
   actual=read(row,row['stock'],'uname -r; cat /etc/machine-id',timeout=8).splitlines()
   if actual==['6.8.0-147-generic',row['machine_id']]:break
  except (subprocess.CalledProcessError,subprocess.TimeoutExpired):pass
  time.sleep(3)
 else:raise RuntimeError('stock observation expired; do not reset')
 address=row['stock'];check(row,address)
 assert read(row,address,'cat /proc/sys/net/ipv4/ip_local_port_range').split()==['32768','60999']
 assert not read(row,address,'cat /proc/sys/net/ipv4/ip_local_reserved_ports').strip()
 assert 'tcpdump' not in read(row,address,'ps -eo comm=').splitlines()
 assert '/home/ubuntu/ssi/tcp-reply-collector.py' not in read(row,address,'ps -eo args=')
 entry=read(row,address,'sudo cat /etc/grub.d/42_sshpool_pf30_grace');assert entry==(work/f'node{n}-entry').read_text()
 (work/f'node{n}-removed-pf30-entry').write_text(entry)
 read(row,address,'sudo rm /etc/grub.d/42_sshpool_pf30_grace && sudo update-grub')
 cfg=read(row,address,'sudo cat /boot/grub/grub.cfg');assert cfg==(work/f'node{n}-before-grub.cfg').read_text()
 assert 'set default="Advanced options for Ubuntu>Ubuntu, with Linux 6.8.0-147-generic"' in cfg
 assert read(row,address,'readlink /lib').strip()=='usr/lib'
 assert not read(row,address,'sudo grub-editenv /boot/grub/grubenv list').strip()
 hashes=read(row,address,'sudo sha256sum /boot/*generic /boot/*pf*');assert hashes==(work/f'node{n}-before-boot.sha256').read_text()
 record={'node':n,'kernel':actual[0],'identity_matches':True,'old_boot_files_unchanged':True,'boot_hash_manifest_sha256':hashlib.sha256(hashes.encode()).hexdigest(),'grub_config_unchanged':True,'firewall_matches_original':True,'lib_target':'usr/lib','grub_environment':'','remaining_processes':[],'remaining_trace_instances':[],'remaining_experiment_tcp':[],'stock_grub_default':True,'pf30_grub_entry_removed':True,'write_grace_reset_before_reboot':True,'ephemeral_range':[32768,60999],'reserved_ports':'','tcp_collectors_absent':True}
 records.append(record);(work/'restoration.json').write_text(json.dumps({'nodes':records},indent=2)+'\n')
 print('stock identity, hashes, firewall and cleanup verified',n,flush=True)
