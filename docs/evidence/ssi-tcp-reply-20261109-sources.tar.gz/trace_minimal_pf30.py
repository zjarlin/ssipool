from pathlib import Path
import json,sys,platform
root=Path('/sys/kernel/tracing');action=sys.argv[1];pid=int(sys.argv[2]);instance=root/'instances'/f'sshpool_grant_{pid}';task=Path('/proc')/str(pid)
assert pid>1 and (task/'comm').read_text().strip()=='probe-grant'
assert platform.release()=='7.1.0-rc3-sshpool-gvm-pf30'
if action=='start':
 assert not list((root/'instances').iterdir()) and not (root/'kprobe_events').read_text().strip()
 before={'kernel':platform.release(),'pid':pid,'stat':(task/'stat').read_text(),'comm':(task/'comm').read_text().strip()}
 instance.mkdir()
 (instance/'tracing_on').write_text('0');(instance/'trace_clock').write_text('global');(instance/'buffer_size_kb').write_text('16384')
 event=instance/'events/kvm/kvm_page_fault'
 (event/'filter').write_text(f'common_pid == {pid}');(event/'enable').write_text('1')
 before.update(trace_clock=(instance/'trace_clock').read_text(),filter=(event/'filter').read_text(),format=(event/'format').read_text())
 (instance/'tracing_on').write_text('1')
 print(json.dumps(before))
elif action=='stop':
 (instance/'tracing_on').write_text('0')
 result={'trace':(instance/'trace').read_text(),'stats':{cpu.name:(cpu/'stats').read_text() for cpu in (instance/'per_cpu').iterdir()},'stat':(task/'stat').read_text()}
 (instance/'events/enable').write_text('0');instance.rmdir();result['cleanup_complete']=not instance.exists()
 print(json.dumps(result))
else:raise ValueError('unknown action')
