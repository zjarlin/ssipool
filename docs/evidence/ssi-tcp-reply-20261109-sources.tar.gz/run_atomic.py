from pathlib import Path
import asyncio,json,subprocess,shlex,time,hashlib,sys,importlib.util
work=Path(__file__).parent
firewall_path=Path('/Users/zjarlin/projects/sshpool/scripts/ssi-lab/lab-firewall.py')
spec=importlib.util.spec_from_file_location('lab_firewall',firewall_path);lab_firewall=importlib.util.module_from_spec(spec);spec.loader.exec_module(lab_firewall)
mode,label=sys.argv[1:3];grace=int(sys.argv[3]);amount=int(sys.argv[4]);assert mode in ('control','pair') and grace in (0,1000) and 0<amount<=4096
assert not (work/(label+'.json')).exists()
count=2 if mode=='pair' else 1
nodes=json.loads((work/'boot.json').read_text())
ssh=['ssh','-F',str(work/'guest_ssh_config'),'-o','BatchMode=yes','-o','ConnectTimeout=8','-o','ServerAliveInterval=10','-o','ServerAliveCountMax=3']
ports=' or '.join(f'{side} = :{port}' for side in ('sport','dport') for port in (37710,37711,40000,40001))
result={'mode':mode,'label':label,'amount':amount,'events':[],'traces':{},'errors':[]};chain='sudo nft -j -a list chain inet sshpool_ssi_lab input';comment='sshpool-atomic-grant';cursors={}
def command(node,text,**kwargs):return subprocess.check_output(ssh+[f'ssi-lab-{node+1}',text],timeout=60,**kwargs)
def idle(node):
 assert command(node,'cat /etc/machine-id').decode().strip()==nodes[node]['machine_id']
 assert command(node,'uname -r').decode().strip()==nodes[node]['kernel']
 names=command(node,'ps -eo comm=').decode().splitlines()
 assert not [s for s in names if s.strip().startswith(('qemu-system-','probe-grant','grant-reader','kvm-dsm/','dsm-conn/','memfd:sshpool'))]
 assert not command(node,'sudo cat /sys/kernel/tracing/kprobe_events; sudo find /sys/kernel/tracing/instances -mindepth 1 -maxdepth 1').strip()
 deadline=time.monotonic()+180
 while command(node,f"ss -H -tan '( {ports} )'").strip():
  if time.monotonic()>deadline:raise RuntimeError('TCP did not drain')
  time.sleep(2)
 assert int(command(node,'df -B1 --output=avail / | tail -1'))>64*1024*1024
def trace(node,action,pid):
 return json.loads(command(node,f'sudo python3 - {action} {pid}',input=(work/'trace_minimal_pf30.py').read_bytes()))
class Worker:
 def __init__(self,node,process):self.node=node;self.process=process;self.pid=None
 async def receive(self):
  line=await asyncio.wait_for(self.process.stdout.readline(),90)
  if not line:raise RuntimeError(f'node {self.node} EOF')
  row=json.loads(line);result['events'].append({'node':self.node,'record':row,'received_ns':time.monotonic_ns()});return row
 async def send(self,text):
  self.process.stdin.write((text+'\n').encode());await self.process.stdin.drain()
 async def expect(self,text,op):
  await self.send(text);row=await self.receive();assert row['op']==op,(text,row);return row
 async def execute(self):
  await self.send('go')
  assert await self.receive()=={'op':'batch_started','amount':amount,'base':0}
  values=[];durations=[]
  for index in range(1,amount+1):
   row=await self.receive();assert row['op']=='atomic' and row['value']==index and row['rip']==4104 and row['exit_reason']==5,row
   values.append(row['previous']);durations.append(row['elapsed_ns'])
  assert await self.receive()=={'op':'writes_done'}
  print('atomic batch complete',self.node,'operations',len(values),'max_ns',max(durations),flush=True)
  return values
async def run():
 workers=[];logs=[];traced=[]
 try:
  for n in range(count):
   peers=[nodes[i]['address'] for i in range(2)] if count==2 else ['127.0.0.1','-']
   log=(work/f'{label}-node{n}-stderr.log').open('xb');logs.append(log)
   process=await asyncio.create_subprocess_exec(*ssh,f'ssi-lab-{n+1}',shlex.join(['sudo','/home/ubuntu/ssi/probe-grant-atomic',str(n),*peers,nodes[n]['kernel'],'--atomic']),stdin=asyncio.subprocess.PIPE,stdout=asyncio.subprocess.PIPE,stderr=log)
   workers.append(Worker(n,process))
  for worker in workers:
   ready=await worker.receive();assert ready['op']=='ready' and ready['node']==worker.node and ready['nodes']==count
   worker.pid=ready['pid'];result['traces'][str(worker.node)]={'before':trace(worker.node,'start',worker.pid)};traced.append(worker)
   await worker.expect('trace','trace_ready')
  result['listener_observations']={}
  for worker in workers:
   snapshot=command(worker.node,"ss -H -ltn '( sport = :"+str(37710+worker.node)+" )'; ip route get "+nodes[1-worker.node]['address']).decode()
   assert snapshot.startswith('LISTEN'),snapshot
   result['listener_observations'][str(worker.node)]=snapshot
  for worker in workers:
   assert await worker.expect('read','read')=={'op':'read','value':0,'guard':0x51a7c0de}
  result['connections_before_batch']={str(n):command(n,"ss -H -tan '( "+ports+" )'").decode() for n in (0,1)}
  for worker in workers:
   assert await worker.expect(f'arm {amount} 0','armed')=={'op':'armed','amount':amount,'base':0}
  values=await asyncio.gather(*(worker.execute() for worker in workers))
  assert sorted(v for node_values in values for v in node_values)==list(range(count*amount)),'duplicate or missing atomic tickets'
  for worker in workers:
   assert await worker.expect('read','read')=={'op':'read','value':count*amount,'guard':0x51a7c0de}
  result['connections_after_batch']={str(n):command(n,"ss -H -tan '( "+ports+" )'").decode() for n in (0,1)}
 except Exception as error:
  result['errors'].append('run: '+type(error).__name__+': '+str(error))
  raise
 finally:
  for worker in traced:
   try:
    await worker.expect('untrace','trace_closed')
    result['traces'][str(worker.node)]['after']=trace(worker.node,'stop',worker.pid)
   except Exception as error:result['errors'].append('trace cleanup: '+str(error))
  if workers:
   generation=time.monotonic_ns()
   closed=await asyncio.gather(*(worker.expect(f'seal {generation}','sealed') for worker in workers),return_exceptions=True)
   for row in closed:
    if isinstance(row,BaseException):result['errors'].append(str(row))
    elif row.get('generation')!=generation:result['errors'].append('close generation mismatch')
   for worker in reversed(workers):
    try:await worker.expect('quit','closed')
    except Exception as error:result['errors'].append('quit node '+str(worker.node)+': '+type(error).__name__+': '+str(error))
    try:
     status=await asyncio.wait_for(worker.process.wait(),60)
     result.setdefault('worker_exits',[]).append({'node':worker.node,'exit':status})
     if status:result['errors'].append('worker exit '+str(status))
    except asyncio.TimeoutError:result['errors'].append('worker remains live node '+str(worker.node))
  for log in logs:log.close()
for n in (0,1):idle(n)
before=[json.loads(command(n,chain)) for n in (0,1)]
assert all(before[n]==json.loads((work/f'node{n}-before-firewall.json').read_text()) for n in (0,1))
parameter='/sys/module/kvm/parameters/dsm_write_grace_us'
result['grace_before']=[int(command(n,'cat '+parameter)) for n in (0,1)];assert result['grace_before']==[0,0]
try:
 for n in (0,1):command(n,'sudo tee '+parameter+' >/dev/null',input=str(grace).encode())
 result['grace_active']=[int(command(n,'cat '+parameter)) for n in (0,1)];assert result['grace_active']==[grace,grace]
 binary=(work/'probe-grant').read_bytes();expected=hashlib.sha256(binary).hexdigest();result['binary_sha256']=expected
 for n in range(count):
  command(n,'cat > /home/ubuntu/ssi/probe-grant-atomic && chmod 755 /home/ubuntu/ssi/probe-grant-atomic',input=binary)
  assert command(n,'sha256sum /home/ubuntu/ssi/probe-grant-atomic').decode().split()[0]==expected
  result.setdefault('kernel_hashes',{})[str(n)]=command(n,'sha256sum /var/lib/sshpool/boot-pf30/vmlinuz-'+nodes[n]['kernel']).decode().split()[0]
  assert result['kernel_hashes'][str(n)]==nodes[n]['kernel_sha256']
  cursors[n]=command(n,'sudo journalctl -k -b -n 0 --show-cursor --no-pager').decode().split('-- cursor: ',1)[1].strip()
 if count==2:
  for n in (0,1):
   rule=lab_firewall.rules(nodes[1-n]['address'],comment)
   command(n,'sudo nft -f -',input=rule.encode())
 result['firewall_before']=before;result['firewall_active']=[json.loads(command(n,chain)) for n in (0,1)]
 asyncio.run(run())
except Exception as error:
 result['errors'].append(type(error).__name__+': '+str(error));raise
finally:
 for n in (0,1):
  current=json.loads(command(n,chain))
  for item in current['nftables']:
   rule=item.get('rule',{})
   if rule.get('comment') in (comment+'-request',comment+'-reply'):command(n,f'sudo nft delete rule inet sshpool_ssi_lab input handle {rule["handle"]}')
 result['firewall_after']=[json.loads(command(n,chain)) for n in (0,1)]
 for n in (0,1):command(n,'sudo tee '+parameter+' >/dev/null',input=b'0')
 result['grace_after']=[int(command(n,'cat '+parameter)) for n in (0,1)];assert result['grace_after']==[0,0]
 for n,cursor in cursors.items():
  (work/f'{label}-node{n}-host.log').write_bytes(command(n,'sudo journalctl -k -b --no-pager --after-cursor='+shlex.quote(cursor)))
 (work/f'{label}.json').write_text(json.dumps(result,indent=2)+'\n')
assert result['firewall_after']==before and not result['errors']
for n in (0,1):idle(n)
result['cleanup_verified']=True
(work/f'{label}.json').write_text(json.dumps(result,indent=2)+'\n')
print('complete and clean',label,flush=True)
