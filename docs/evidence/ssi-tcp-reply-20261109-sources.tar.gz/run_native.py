from pathlib import Path
import json,subprocess,sys
work=Path(__file__).parent;nodes=json.loads((work/'boot.json').read_text());parameter='/proc/sys/net/ipv4/ip_local_port_range';label='pf30-tcp-reply-pair-fixed-a'
assert not (work/(label+'.json')).exists() and not (work/'port-range-control.json').exists()
base=['ssh','-F',str(work/'guest_ssh_config'),'-o','BatchMode=yes','-o','ConnectTimeout=8']
def command(n,text,data=None):return subprocess.check_output(base+[f'ssi-lab-{n+1}',text],input=data,timeout=30).decode()
for n in (0,1):
 assert command(n,'cat /etc/machine-id; uname -r').splitlines()==[nodes[n]['machine_id'],nodes[n]['kernel']]
 assert not command(n,'cat /proc/sys/net/ipv4/ip_local_reserved_ports').strip()
before=[command(n,'cat '+parameter) for n in (0,1)];assert [x.split() for x in before]==[['32768','60999']]*2
result={'label':label,'before':before,'forced':[37742,37773]}
try:
 for n in (0,1):command(n,'sudo tee '+parameter+' >/dev/null',b'37742 37773\n')
 result['active']=[command(n,'cat '+parameter) for n in (0,1)];assert [x.split() for x in result['active']]==[['37742','37773']]*2
 (work/'port-range-control.json').write_text(json.dumps(result,indent=2)+'\n')
 process=subprocess.run([sys.executable,'-u',str(work/'run_atomic.py'),'pair',label,'1000','4096'])
 result['runner_exit']=process.returncode
finally:
 for n in (0,1):command(n,'sudo tee '+parameter+' >/dev/null',before[n].encode())
 result['after']=[command(n,'cat '+parameter) for n in (0,1)]
 (work/'port-range-control.json').write_text(json.dumps(result,indent=2)+'\n')
assert result['after']==before and result['runner_exit']==0
print('native run complete and original source port ranges restored',flush=True)
