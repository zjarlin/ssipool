from pathlib import Path
import json,subprocess,time,shlex,hashlib
w=Path(__file__).parent;prior=w.parent/'write-grant-progress';nodes=json.loads((w/'nodes.json').read_text());base=['ssh','-F',str(w/'guest_ssh_config'),'-o','BatchMode=yes','-o','ConnectTimeout=5']
kernel='7.1.0-rc3-sshpool-gvm-pf30';label='SSHPool PF30 write grace experiment';target='/etc/grub.d/42_sshpool_pf30_grace'
def read(row,address,cmd,timeout=90,input=None):
 return subprocess.check_output(base+['-o','HostName='+address,f'ssi-lab-{row["node"]+1}',cmd],input=input,timeout=timeout,stderr=subprocess.PIPE).decode()
records=[]
for row in nodes:
 n=row['node'];address=row['stock']
 assert read(row,address,'cat /etc/machine-id; uname -r').splitlines()==[row['machine_id'],'6.8.0-147-generic']
 names=read(row,address,'ps -eo comm=').splitlines();assert not [s for s in names if s.strip().startswith(('qemu-system-','probe-grant','grant-reader','kvm-dsm/','dsm-conn/','memfd:sshpool'))]
 ports=' or '.join(f'{side} = :{p}' for side in ('sport','dport') for p in (37710,37711,40000,40001,22230))
 assert not read(row,address,f"ss -H -tan '( {ports} )'").strip()
 assert not read(row,address,'sudo cat /sys/kernel/tracing/kprobe_events; sudo find /sys/kernel/tracing/instances -mindepth 1 -maxdepth 1').strip()
 assert not read(row,address,'sudo grub-editenv /boot/grub/grubenv list').strip()
 assert int(read(row,address,'df -B1 --output=avail / | tail -1'))>=64*1024*1024
 assert read(row,address,f'sha256sum /var/lib/sshpool/boot-pf30/vmlinuz-{kernel}').split()[0]==row['kernel_sha256']
 for name,cmd in {'grub.cfg':'sudo cat /boot/grub/grub.cfg','boot.sha256':'sudo sha256sum /boot/*generic /boot/*pf*','firewall.json':'sudo nft -j -a list chain inet sshpool_ssi_lab input'}.items():
  data=read(row,address,cmd)
  assert data==(prior/f'node{n}-before-{name}').read_text()
  (w/f'node{n}-before-{name}').write_text(data)
 entry=(prior/'pf30'/f'node{n}-entry').read_text();assert read(row,address,'sudo grub-probe -t fs_uuid /').strip() in entry
 read(row,address,f'test ! -e {target} && sudo tee {target} >/dev/null && sudo chmod 755 {target} && sudo update-grub && sudo grub-script-check /boot/grub/grub.cfg',input=entry.encode())
 cfg=read(row,address,'sudo cat /boot/grub/grub.cfg');assert cfg.count("menuentry '"+label+"'")==1
 assert 'set default="Advanced options for Ubuntu>Ubuntu, with Linux 6.8.0-147-generic"' in cfg
 (w/f'node{n}-entry').write_text(entry);(w/f'node{n}-grub.cfg').write_text(cfg)
 read(row,address,'sudo grub-reboot '+shlex.quote(label)+' && sudo systemctl reboot')
 print('PF30 one-shot reboot requested',n,flush=True)
 deadline=time.monotonic()+300
 while time.monotonic()<deadline:
  try:
   if read(row,row['research'],'uname -r; cat /etc/machine-id',timeout=8).splitlines()==[kernel,row['machine_id']]:break
  except (subprocess.CalledProcessError,subprocess.TimeoutExpired):pass
  time.sleep(3)
 else:raise RuntimeError('observation timed out; inspect without resetting')
 address=row['research']
 assert read(row,address,'cat /sys/module/kvm_intel/parameters/enable_apicv; cat /sys/module/kvm_intel/parameters/dsm_force_pause_exit; cat /sys/module/kvm/parameters/dsm_write_grace_us').splitlines()==['N','Y','0']
 read(row,address,'sudo grub-editenv /boot/grub/grubenv unset next_entry')
 records.append({**row,'address':address,'kernel':kernel})
 (w/'boot.json').write_text(json.dumps(records,indent=2)+'\n')
 print('PF30 identity and controls verified',n,flush=True)
