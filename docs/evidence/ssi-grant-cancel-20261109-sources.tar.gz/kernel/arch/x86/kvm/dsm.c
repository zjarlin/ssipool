// SPDX-License-Identifier: GPL-2.0
/*
 * Support KVM software distributed memory
 *
 * This feature allows us to run multiple KVM instances on different machines
 * sharing the same address space.
 *
 * Copyright (C) 2019-2026, Trusted Cloud Group,Institute of Scalable Computing,
 * Shanghai Jiao Tong University.
 *
 * Authors:
 *   Chen Yubin <binsschen@sjtu.edu.cn>
 *   Ding Zhuocheng <tcbbd@sjtu.edu.cn>
 *   Zhang Jin <jzhang3002@sjtu.edu.cn>
 *
 * This work is licensed under the terms of the GNU GPL, version 2.  See
 * the COPYING file in the top-level directory.
 */

#include <linux/kvm_host.h>
#include <linux/limits.h>
#include <linux/kvm.h>
#include "dsm.h"
#include "dsm-close.h"
#include "mmu.h"
#include "ioapic.h"
#include "lapic.h"

#include <linux/kthread.h>
#include <linux/inet.h>
#include <linux/mmu_context.h>
#include "smm.h"

static int kvm_dsm_page_fault(struct kvm *kvm, struct kvm_memory_slot *memslot,
			      gfn_t gfn, bool is_smm, int write);

/*
 * The old dsm_memslots are free here rather than kvm_dsm_remove_memslot.
 */
int kvm_dsm_register_memslot_hva(struct kvm *kvm, struct kvm_memory_slot *slot,
				 unsigned long npages)
{
	int ret, i;
	hfn_t base_vfn, start, end;
	struct kvm_dsm_memslots *slots = NULL, *old_slots = __kvm_hvaslots(kvm);
	struct kvm_dsm_memory_slot *old_slot;

	if (!kvm->arch.dsm_enabled || slot->id >= KVM_USER_MEM_SLOTS)
		return 0;

	slots = kvzalloc(sizeof(*slots), GFP_KERNEL);
	if (!slots)
		return -ENOMEM;

	memcpy(slots, old_slots, sizeof(struct kvm_dsm_memslots));

	base_vfn = slot->userspace_addr >> PAGE_SHIFT;
	for (i = 0; i < old_slots->used_slots; i++) {
		if (base_vfn >= old_slots->memslots[i].base_vfn)
			continue;
		if (i == 0) {
			start = base_vfn;
			end = min(base_vfn + npages,
				  old_slots->memslots[i].base_vfn);
		} else {
			old_slot = &old_slots->memslots[i - 1];
			if (base_vfn + npages <=
			    old_slot->base_vfn + old_slot->npages)
				continue;
			start = max(base_vfn,
				    old_slot->base_vfn + old_slot->npages);
			end = min(base_vfn + npages,
				  old_slots->memslots[i].base_vfn);
			if (start == end)
				continue;
		}

		ret = insert_hvaslot(slots, i, start, end - start);
		if (ret < 0)
			goto out_free;
	}

	if (old_slots->used_slots == 0) {
		start = base_vfn;
		end = base_vfn + npages;
	} else {
		old_slot = &old_slots->memslots[old_slots->used_slots - 1];
		start = max(base_vfn, old_slot->base_vfn + old_slot->npages);
		end = base_vfn + npages;
	}
	if (end > start) {
		ret = insert_hvaslot(slots, old_slots->used_slots, start,
				     end - start);
		if (ret < 0)
			goto out_free;
	}

	rcu_assign_pointer(kvm->arch.dsm_hvaslots, slots);
	synchronize_srcu_expedited(&kvm->srcu);
	kvfree(old_slots);
	return 0;

out_free:
	kvfree(slots);
	return ret;
}

/* This should happen before the new memslot is added to kvm_memslots */
int kvm_dsm_add_memslot(struct kvm *kvm, struct kvm_memory_slot *slot,
			int as_id)
{
	struct kvm_dsm_memslots *slots;
	struct kvm_dsm_memory_slot *hvaslot, *new_hvaslot;
	unsigned long npages;
	gfn_t gfn, gfn_end, gfn_iter;
	hfn_t vfn;
	int ret = 0, i, iter_idx;
	bool flag;

	gfn_end = slot->base_gfn + slot->npages;
	slots = __kvm_hvaslots(kvm);
	for (gfn = slot->base_gfn; gfn < gfn_end; gfn += npages) {
		flag = false;
		npages = 1;
		for (i = 0; i < slots->used_slots; i++) {
			hvaslot = &slots->memslots[i];
			iter_idx = 0;
			while (iter_idx >= 0) {
				bool is_smm;

				gfn_iter = __kvm_dsm_vfn_to_gfn(
					hvaslot, true, hvaslot->base_vfn,
					&is_smm, &iter_idx, NULL);
				if (!!is_smm == !!as_id && gfn_iter <= gfn &&
				    gfn_iter + hvaslot->npages > gfn) {
					flag = true;
					break;
				}
			}
			if (flag)
				break;
		}
		if (!flag)
			continue;
		vfn = __gfn_to_vfn_memslot(slot, gfn);
		new_hvaslot = gfn_to_hvaslot(kvm, slot, gfn);
		if (new_hvaslot == hvaslot)
			continue;
		npages = min(gfn_end - gfn,
			     min(hvaslot->npages - (gfn - gfn_iter),
				 new_hvaslot->npages -
					 (vfn - new_hvaslot->base_vfn)));
		/* Retrieve dsm state from backup in case of gfn->vfn mapping changes. */
		for (i = 0; i < npages; i++) {
			new_hvaslot
				->vfn_dsm_state[i +
						(vfn - new_hvaslot->base_vfn)]
				.state =
				hvaslot->vfn_dsm_state[i + (gfn - gfn_iter)]
					.state;
			memcpy(new_hvaslot
				       ->vfn_dsm_state[i +
						       (vfn -
							new_hvaslot->base_vfn)]
				       .copyset,
			       hvaslot->vfn_dsm_state[i + (gfn - gfn_iter)]
				       .copyset,
			       sizeof(copyset_t));
		}
		kvm_dsm_rmap_remove(kvm, hvaslot, true,
				    (gfn << 1) | GFN_PRESENT_MASK |
					    (as_id ? GFN_SMM_MASK : 0),
				    hvaslot->base_vfn + (gfn - gfn_iter),
				    npages);
	}

	for (gfn = slot->base_gfn; gfn < gfn_end; gfn += npages) {
		vfn = __gfn_to_vfn_memslot(slot, gfn);
		hvaslot = gfn_to_hvaslot(kvm, slot, gfn);
		/* ignore private memslots, they have no corresponding hvaslots */
		if (!hvaslot)
			return 0;
		npages = min(gfn_end - gfn,
			     hvaslot->base_vfn + hvaslot->npages - vfn);
		ret = kvm_dsm_rmap_add(kvm, hvaslot, false,
				       (gfn << 1) | GFN_PRESENT_MASK |
					       (as_id ? GFN_SMM_MASK : 0),
				       vfn, npages);
		if (ret < 0)
			goto out_free;
	}
	return ret;

out_free:
	gfn_end = gfn;
	for (gfn = slot->base_gfn; gfn < gfn_end; gfn += npages) {
		vfn = __gfn_to_vfn_memslot(slot, gfn);
		hvaslot = gfn_to_hvaslot(kvm, slot, gfn);
		npages = min(gfn_end - gfn,
			     hvaslot->base_vfn + hvaslot->npages - vfn);
		kvm_dsm_rmap_remove(kvm, hvaslot, false,
				    (gfn << 1) | GFN_PRESENT_MASK |
					    (as_id ? GFN_SMM_MASK : 0),
				    vfn, npages);
	}
	return ret;
}

/* This should happen after the old memslot is marked invalid in kvm_memslots */
void kvm_dsm_remove_memslot(struct kvm *kvm, struct kvm_memory_slot *slot)
{
	struct kvm_memslots *memslots;
	struct kvm_memory_slot *memslot;
	struct kvm_dsm_memory_slot *hvaslot;
	unsigned long npages;
	gfn_t gfn, gfn_end;
	hfn_t vfn;
	int i, bkt;

	/*
	 * The slot passed in is exactly the memory slot marked invalid in the
	 * current kvm_memslots, so we can find if the slot is in smm space.
	 *
	 * XXX: Or maybe we can use KVM_MEMSLOT_INVALID as the indicator of the
	 * matching memslot, as there should be only one slot that is invalid at a
	 * given time.
	 */
	for (i = 0; i < kvm_arch_nr_memslot_as_ids(kvm); i++) {
		memslots = __kvm_memslots(kvm, i);
		kvm_for_each_memslot(memslot, bkt, memslots) {
			if (memslot == slot)
				goto out;
		}
	}
out:
	if (i == kvm_arch_nr_memslot_as_ids(kvm))
		return;

	gfn_end = slot->base_gfn + slot->npages;
	for (gfn = slot->base_gfn; gfn < gfn_end; gfn += npages) {
		vfn = __gfn_to_vfn_memslot(slot, gfn);
		hvaslot = gfn_to_hvaslot(kvm, slot, gfn);
		/* ignore private memslots, they have no corresponding hvaslots */
		if (!hvaslot)
			return;
		npages = min(gfn_end - gfn,
			     hvaslot->base_vfn + hvaslot->npages - vfn);
		kvm_dsm_rmap_remove(kvm, hvaslot, false,
				    (gfn << 1) | GFN_PRESENT_MASK |
					    (i ? GFN_SMM_MASK : 0),
				    vfn, npages);
		/* Backup dsm state. */
		kvm_dsm_rmap_add(kvm, hvaslot, true,
				 (gfn << 1) | GFN_PRESENT_MASK |
					 (i ? GFN_SMM_MASK : 0),
				 vfn, npages);
	}
}

/*
 * Should be called inside kvm->srcu or kvm->slots_lock, and paired with
 * kvm_dsm_release_page.
 */
static int __kvm_dsm_acquire_page(struct kvm *kvm, struct kvm_memory_slot *slot,
				  gfn_t gfn, bool is_smm, bool write)
{
	struct kvm_dsm_memory_slot *hvaslot;
	hfn_t vfn;
	int dsm_access;

	if (WARN_ON(kvm->mm != current->mm))
		return -EINVAL;
	if (!kvm->arch.dsm_enabled)
		return ACC_ALL;
	if (READ_ONCE(kvm->arch.dsm_error))
		return READ_ONCE(kvm->arch.dsm_error);

	/*
	 * We should ignore private memslots since they are not really visible
	 * to guest and thus are not part of guest state that should be
	 * distributedly shared.
	 */
	if (!slot || slot->id >= KVM_USER_MEM_SLOTS ||
	    slot->flags & KVM_MEMSLOT_INVALID)
		return ACC_ALL;

	vfn = __gfn_to_vfn_memslot(slot, gfn);

	hvaslot = gfn_to_hvaslot(kvm, slot, gfn);

	if (!hvaslot)
		return ACC_ALL;

	dsm_lock(kvm, hvaslot, vfn, NULL);
	dsm_access = kvm_dsm_page_fault(kvm, slot, gfn, is_smm, write);
	if (dsm_access < 0)
		dsm_unlock(kvm, hvaslot, vfn, NULL);
	return dsm_access;
}

int kvm_dsm_acquire_page(struct kvm *kvm, struct kvm_memory_slot **slot,
			 gfn_t gfn, bool write)
{
	struct kvm_memory_slot *memslot;

	memslot = gfn_to_memslot(kvm, gfn);
	if (slot)
		*slot = memslot;
	return __kvm_dsm_acquire_page(kvm, memslot, gfn, 0, write);
}

int kvm_dsm_vcpu_acquire_page(struct kvm_vcpu *vcpu,
			      struct kvm_memory_slot **slot, gfn_t gfn,
			      bool write)
{
	struct kvm_memory_slot *memslot;

	memslot = kvm_vcpu_gfn_to_memslot(vcpu, gfn);
	if (slot)
		*slot = memslot;
	return __kvm_dsm_acquire_page(vcpu->kvm, memslot, gfn, is_smm(vcpu),
				      write);
}

/*
 * Should be called inside kvm->srcu or kvm->slots_lock, and paired with
 * kvm_dsm_acquire_page.
 */
void kvm_dsm_release_page(struct kvm *kvm, struct kvm_memory_slot *slot,
			  gfn_t gfn)
{
	struct kvm_dsm_memory_slot *hvaslot;
	hfn_t vfn;

	if (WARN_ON(kvm->mm != current->mm))
		return;

	if (!kvm->arch.dsm_enabled || !slot || slot->id >= KVM_USER_MEM_SLOTS ||
	    slot->flags & KVM_MEMSLOT_INVALID)
		return;

	vfn = __gfn_to_vfn_memslot(slot, gfn);
	hvaslot = gfn_to_hvaslot(kvm, slot, gfn);
	if (!hvaslot)
		return;
	dsm_unlock_fast_path(hvaslot, vfn, false);
	dsm_unlock(kvm, hvaslot, vfn, NULL);
}

void kvm_dsm_vcpu_release_page(struct kvm_vcpu *vcpu,
			       struct kvm_memory_slot *slot, gfn_t gfn)
{
	kvm_dsm_release_page(vcpu->kvm, slot, gfn);
}

int kvm_dsm_acquire(struct kvm *kvm, struct kvm_memslots **slots, gpa_t gpa,
		    unsigned long len, bool write)
{
	struct kvm_memslots *memslots;
	struct kvm_memory_slot *slot;
	gfn_t gfn, gfn_end = (gpa + len - 1) >> PAGE_SHIFT;
	int ret = ACC_ALL;

	memslots = __kvm_memslots(kvm, 0);
	if (slots)
		*slots = memslots;
	for (gfn = gpa >> PAGE_SHIFT; gfn <= gfn_end; gfn++) {
		slot = __gfn_to_memslot(memslots, gfn);
		ret = __kvm_dsm_acquire_page(kvm, slot, gfn, 0, write);
		if (ret < 0)
			goto out_release;
	}
	return ret;

out_release:
	while (--gfn >= (gpa >> PAGE_SHIFT)) {
		slot = __gfn_to_memslot(memslots, gfn);
		kvm_dsm_release_page(kvm, slot, gfn);
	}
	return ret;
}

int kvm_dsm_vcpu_acquire(struct kvm_vcpu *vcpu, struct kvm_memslots **slots,
			 gpa_t gpa, unsigned long len, bool write)
{
	struct kvm_memslots *memslots;
	struct kvm_memory_slot *slot;
	gfn_t gfn, gfn_end = (gpa + len - 1) >> PAGE_SHIFT;
	int ret = ACC_ALL;

	memslots = kvm_vcpu_memslots(vcpu);
	if (slots)
		*slots = memslots;
	for (gfn = gpa >> PAGE_SHIFT; gfn <= gfn_end; gfn++) {
		slot = __gfn_to_memslot(memslots, gfn);
		ret = __kvm_dsm_acquire_page(vcpu->kvm, slot, gfn, is_smm(vcpu),
					     write);
		if (ret < 0)
			goto out_release;
	}
	return ret;

out_release:
	while (--gfn >= (gpa >> PAGE_SHIFT)) {
		slot = __gfn_to_memslot(memslots, gfn);
		kvm_dsm_vcpu_release_page(vcpu, slot, gfn);
	}
	return ret;
}

void kvm_dsm_release(struct kvm *kvm, struct kvm_memslots *slots, gpa_t gpa,
		     unsigned long len)
{
	struct kvm_memory_slot *slot;
	gfn_t gfn, gfn_end = (gpa + len - 1) >> PAGE_SHIFT;

	if (WARN_ON_ONCE(!slots))
		return;
	for (gfn = gpa >> PAGE_SHIFT; gfn <= gfn_end; gfn++) {
		slot = __gfn_to_memslot(slots, gfn);
		kvm_dsm_release_page(kvm, slot, gfn);
	}
}

void kvm_dsm_vcpu_release(struct kvm_vcpu *vcpu, struct kvm_memslots *slots,
			  gpa_t gpa, unsigned long len)
{
	struct kvm_memory_slot *slot;
	gfn_t gfn, gfn_end = (gpa + len - 1) >> PAGE_SHIFT;

	if (WARN_ON_ONCE(!slots))
		return;
	for (gfn = gpa >> PAGE_SHIFT; gfn <= gfn_end; gfn++) {
		slot = __gfn_to_memslot(slots, gfn);
		kvm_dsm_vcpu_release_page(vcpu, slot, gfn);
	}
}

/* DSM server functions entry. */
static int kvm_dsm_handle_req(void *data)
{
	return ivy_kvm_dsm_handle_req(data);
}

/*
 * kvm_dsm_init: init
 * kvm_dsm_threadfn: kvm-dsm
 * kvm_dsm_handle_req: dsm-conn
 *
 * init spanws one kvm-dsm.
 * Upon accepting any incoming connections, kvm-dsm spanws NDSM_CONN_THREADS
 * dsm-conn.
 * Invariant: Inv request should not be blocked. The multiple server threads
 * help.
 */
/* 初始化失败和 VM 销毁共用回收；调用前必须停止所有连接线程。 */
static void kvm_dsm_free_config(struct kvm *kvm)
{
	int i;

	if (kvm->arch.dsm_conn_socks) {
		for (i = 0; i < DSM_MAX_INSTANCES * 2; i++) {
			if (kvm->arch.dsm_conn_socks[i])
				network_ops.release(kvm->arch.dsm_conn_socks[i]);
		}
		kfree(kvm->arch.dsm_conn_socks);
		kvm->arch.dsm_conn_socks = NULL;
	}
	if (kvm->arch.dsm_listen_sock) {
		network_ops.release(kvm->arch.dsm_listen_sock);
		kvm->arch.dsm_listen_sock = NULL;
	}
	for (i = 0; i < kvm->arch.cluster_iplist_len; i++)
		kfree(kvm->arch.cluster_iplist[i]);
	kfree(kvm->arch.cluster_iplist);
	kvm->arch.cluster_iplist = NULL;
	kvm->arch.cluster_iplist_len = 0;
}

/* 通知标准 KVM 管理接口，并唤醒根线程统一中止全部连接。 */
void kvm_dsm_fail(struct kvm *kvm, int error)
{
	struct task_struct *root;
	unsigned long flags;
	int first;

	if (WARN_ON_ONCE(error >= 0))
		error = -EIO;
	/* 首次错误与传输封闭使用相同临界区，已知故障不得被零计数覆盖。 */
	spin_lock_irqsave(&kvm->arch.dsm_admission_lock, flags);
	first = cmpxchg(&kvm->arch.dsm_error, 0, error);
	spin_unlock_irqrestore(&kvm->arch.dsm_admission_lock, flags);
	if (first)
		return;
	pr_err("kvm-dsm: node-%d failed with %d; VM cannot continue\n",
	       kvm->arch.dsm_id, error);
	wake_up_all(&kvm->arch.dsm_ioctl_wait);
	kvm_vm_dead(kvm);
	root = READ_ONCE(kvm->arch.dsm_thread);
	if (root && root != current)
		send_sig(SIGKILL, root, 1);
}

static int kvm_dsm_threadfn(void *data)
{
	struct kvm *kvm = data;
	kconnection_t *accept_sock;
	struct dsm_conn *conn;
	struct task_struct *thread;
	LIST_HEAD(conn_list);
	int ret = 0, stopped, i, count = 0, abort_error;
	char comm[TASK_COMM_LEN];

	allow_signal(SIGKILL);
	while (!kthread_should_stop() && !fatal_signal_pending(current) &&
	       !READ_ONCE(kvm->arch.dsm_stopped) && !READ_ONCE(kvm->arch.dsm_error) &&
	       !dsm_close_complete(kvm)) {
		if (dsm_close_frozen(kvm)) {
			wait_event_interruptible(kvm->arch.dsm_ioctl_wait,
				dsm_close_complete(kvm) || READ_ONCE(kvm->arch.dsm_error) ||
				READ_ONCE(kvm->arch.dsm_stopped) || kthread_should_stop());
			continue;
		}
		ret = network_ops.accept(kvm->arch.dsm_listen_sock, &accept_sock, O_NONBLOCK);
		if (ret == -EAGAIN) {
			ret = dsm_close_freeze_listener(kvm);
			if (ret) {
				break;
			}
			wait_event_interruptible_timeout(kvm->arch.dsm_ioctl_wait,
				dsm_close_complete(kvm) || READ_ONCE(kvm->arch.dsm_error) ||
				kthread_should_stop(), msecs_to_jiffies(10));
			continue;
		}
		if (ret < 0) {
			if (ret == -ERESTARTSYS)
				ret = 0;
			break;
		}
		conn = kzalloc(sizeof(*conn), GFP_KERNEL);
		if (!conn) {
			network_ops.release(accept_sock);
			ret = -ENOMEM;
			break;
		}
		ret = dsm_close_accept(kvm);
		if (ret) {
			network_ops.release(accept_sock);
			kfree(conn);
			break;
		}
		conn->kvm = kvm;
		conn->sock = accept_sock;
		mutex_init(&conn->dispatch_lock);
		atomic_set(&conn->active_requests, 0);
		init_waitqueue_head(&conn->drain_wait);
		/* 提前登记，部分线程创建失败也走相同的停止与回收路径。 */
		list_add_tail(&conn->link, &conn_list);
		for (i = 0; i < NDSM_CONN_THREADS; i++) {
			thread = kthread_create(kvm_dsm_handle_req, conn,
						"dsm-conn/%d:%d", kvm->arch.dsm_id,
						count++);
			if (IS_ERR(thread)) {
				ret = PTR_ERR(thread);
				pr_err("kvm-dsm: failed to create connection thread: %d\n", ret);
				goto out;
			}
			/* 在线程开始执行前持有引用，允许它因错误提前退出。 */
			get_task_struct(thread);
			conn->threads[i] = thread;
			wake_up_process(thread);
		}
	}
	if (!ret && fatal_signal_pending(current) && !dsm_close_complete(kvm)) {
		ret = -EINTR;
	}
out:
	if (ret && !READ_ONCE(kvm->arch.dsm_stopped))
		kvm_dsm_fail(kvm, ret);
	if (dsm_close_complete(kvm) && !READ_ONCE(kvm->arch.dsm_error)) {
		goto join;
	}
	abort_error = READ_ONCE(kvm->arch.dsm_error) ?: -EPIPE;
	dsm_close_abort(kvm, abort_error);
	/* 先中断网络，避免处理线程或 vCPU 持页锁等待永远不会到来的响应。 */
	network_ops.abort(kvm->arch.dsm_listen_sock, abort_error);
	for (i = 0; i < DSM_MAX_INSTANCES * 2; i++) {
		kconnection_t *outgoing = smp_load_acquire(&kvm->arch.dsm_conn_socks[i]);

		if (outgoing)
			network_ops.abort(outgoing, abort_error);
	}
	list_for_each_entry(conn, &conn_list, link)
		network_ops.abort(conn->sock, abort_error);
	/* 先通知所有线程，避免先等待的线程依赖尚未收到退出信号的同伴。 */
	list_for_each_entry(conn, &conn_list, link) {
		for (i = 0; i < NDSM_CONN_THREADS; i++) {
			if (conn->threads[i])
				send_sig(SIGKILL, conn->threads[i], 1);
		}
	}
join:
	while (!list_empty(&conn_list)) {
		conn = list_first_entry(&conn_list, struct dsm_conn, link);
		list_del(&conn->link);
		for (i = 0; i < NDSM_CONN_THREADS; i++) {
			thread = conn->threads[i];
			if (!thread)
				continue;
			get_task_comm(comm, thread);
			stopped = kthread_stop(thread);
			put_task_struct(thread);
			dsm_debug("kvm[%d] dsm connection thread %s exited with %d",
				  kvm->arch.dsm_id, comm, stopped);
			/* 不让后续成功退出覆盖先前线程或监听器的错误。 */
			if (!ret && stopped)
				ret = stopped;
		}
		network_ops.release(conn->sock);
		kfree(conn);
	}
	clean_couter();
	dsm_close_root_done(kvm);
	return READ_ONCE(kvm->arch.dsm_error) ?: ret;
}

static int kvm_dsm_init(struct kvm *kvm, struct kvm_dsm_params *params)
{
	int ret = 0, i;
	struct task_struct *thread;
	char **user_cluster_iplist = NULL;
	struct dsm_address addr;
	__be32 address;
	const char *end;

	if (!params->cluster_iplist_len ||
	    params->cluster_iplist_len > DSM_MAX_INSTANCES ||
	    params->dsm_id >= params->cluster_iplist_len)
		return -EINVAL;
	if (kvm->arch.dsm_enabled)
		return 0;
	/* 调用方持有 kvm->lock，与开启 dirty ring 的路径互斥。 */
	if (kvm->dirty_ring_size)
		return -EOPNOTSUPP;

	kvm->arch.cluster_iplist = kcalloc(params->cluster_iplist_len,
					 sizeof(char *), GFP_KERNEL);
	if (!kvm->arch.cluster_iplist)
		return -ENOMEM;
	kvm->arch.cluster_iplist_len = params->cluster_iplist_len;
	user_cluster_iplist = kcalloc(params->cluster_iplist_len,
				     sizeof(char *), GFP_KERNEL);
	if (!user_cluster_iplist) {
		ret = -ENOMEM;
		goto out;
	}
	if (copy_from_user(user_cluster_iplist, params->cluster_iplist,
			   sizeof(char *) * params->cluster_iplist_len)) {
		ret = -EFAULT;
		goto out;
	}
	for (i = 0; i < params->cluster_iplist_len; i++) {
		char *host = strndup_user(user_cluster_iplist[i], 20);

		if (IS_ERR(host)) {
			ret = PTR_ERR(host);
			goto out;
		}
		kvm->arch.cluster_iplist[i] = host;
		if (!in4_pton(host, -1, (u8 *)&address, -1, &end) || *end) {
			ret = -EINVAL;
			goto out;
		}
	}
	kfree(user_cluster_iplist);
	user_cluster_iplist = NULL;

	mutex_init(&kvm->arch.conn_init_lock);
	network_ops.send = ktcp_send;
	network_ops.receive = ktcp_receive;
	network_ops.connect = ktcp_connect;
	network_ops.listen = ktcp_listen;
	network_ops.accept = ktcp_accept;
	network_ops.release = ktcp_release;
	network_ops.abort = ktcp_abort;
	kvm->arch.dsm_conn_socks = kcalloc(DSM_MAX_INSTANCES * 2,
					 sizeof(kconnection_t *), GFP_KERNEL);
	if (!kvm->arch.dsm_conn_socks) {
		ret = -ENOMEM;
		goto out;
	}
	kvm->arch.dsm_id = params->dsm_id;
	ret = get_dsm_address(kvm, params->dsm_id, &addr);
	if (ret)
		goto out;
	/* 在 ioctl 返回前完成绑定和监听，让端口冲突直接返回调用方。 */
	ret = network_ops.listen(addr.host, addr.port, &kvm->arch.dsm_listen_sock);
	if (ret)
		goto out;
	thread = kthread_create(kvm_dsm_threadfn, kvm, "kvm-dsm/%d", params->dsm_id);
	if (IS_ERR(thread)) {
		ret = PTR_ERR(thread);
		goto out;
	}
	get_task_struct(thread);
	kvm->arch.dsm_thread = thread;
	kvm->arch.dsm_stopped = false;
	kvm->arch.dsm_enabled = true;
	wake_up_process(thread);
	return 0;
out:
	kfree(user_cluster_iplist);
	kvm_dsm_free_config(kvm);
	return ret;
}

int kvm_dsm_alloc(struct kvm *kvm)
{
	spin_lock_init(&kvm->arch.dsm_admission_lock);
	init_waitqueue_head(&kvm->arch.dsm_ioctl_wait);
	mutex_init(&kvm->arch.dsm_lock);
	mutex_init(&kvm->arch.dsm_pin_refs_lock);
	kvm->arch.dsm_hvaslots =
		kvzalloc(sizeof(*kvm->arch.dsm_hvaslots), GFP_KERNEL);
	if (!kvm->arch.dsm_hvaslots)
		return -ENOMEM;

	if (dsm_close_alloc(kvm)) {
		kvfree(kvm->arch.dsm_hvaslots);
		kvm->arch.dsm_hvaslots = NULL;
		return -ENOMEM;
	}
	return 0;
}

/* 在 KVM 仍保有 vCPU、MMU 和路由时停止 DSM 使用者；重复调用不重复回收。 */
void kvm_dsm_stop(struct kvm *kvm)
{
	int ret;

	if (kvm->arch.dsm_enabled && kvm->arch.dsm_thread) {
		pr_devel("kvm-dsm: node-%d stopping dsm server\n",
			 kvm->arch.dsm_id);
		WRITE_ONCE(kvm->arch.dsm_stopped, true);
		dsm_close_cancel(kvm);
		wake_up_all(&kvm->arch.dsm_ioctl_wait);
		/* Ensure dsm_enabled is visible before checking dsm_thread */
		smp_mb();
		send_sig(SIGKILL, kvm->arch.dsm_thread, 1);
		ret = kthread_stop(kvm->arch.dsm_thread);
		put_task_struct(kvm->arch.dsm_thread);
		kvm->arch.dsm_thread = NULL;
		if (ret < 0) {
			pr_err("%s: node-%d dsm root server exited with %d\n",
			       __func__, kvm->arch.dsm_id, ret);
		}
	}
}

void kvm_dsm_free(struct kvm *kvm)
{
	int i;
	struct kvm_dsm_memslots *slots;

	/* 创建失败路径可能跳过预销毁钩子，仍保留幂等的停止步骤。 */
	kvm_dsm_stop(kvm);
	/* 监听器归 VM 所有，即使线程尚未运行就被停止，也必须释放。 */
	kvm_dsm_free_config(kvm);
	dsm_close_free(kvm);

	slots = kvm->arch.dsm_hvaslots;
	if (!slots)
		return;

	for (i = 0; i < KVM_MEM_SLOTS_NUM; i++) {
		kvfree(slots->memslots[i].vfn_dsm_state);
		kvm_dsm_free_rmap(kvm, &slots->memslots[i]);
		kvfree(slots->memslots[i].rmap);
		kvfree(slots->memslots[i].backup_rmap);
		kvfree(slots->memslots[i].rmap_lock);
	}
	kvfree(slots);
}

static int kvm_dsm_page_fault(struct kvm *kvm, struct kvm_memory_slot *memslot,
			      gfn_t gfn, bool is_smm, int write)
{
	return ivy_kvm_dsm_page_fault(kvm, memslot, gfn, is_smm, write);
}

static int kvm_dsm_memcpy(struct kvm *kvm, unsigned long host_virt_addr,
			  unsigned long userspace_addr, unsigned long length,
			  bool write)
{
	struct kvm_dsm_memory_slot *slot;
	struct kvm_memory_slot *memslot;
	hfn_t vfn, vfn_end;
	gfn_t gfn;
	bool is_smm;
	unsigned long npages, gfn_npages, i, j;
	unsigned long hva_start, hva_end, l;
	void *user_buf;
	int idx, ret = 0;

	if (current->mm != kvm->mm)
		return -EFAULT;
	if (!kvm->arch.dsm_enabled)
		return -EINVAL;

	if (!length)
		return 0;
	if (length > ULONG_MAX - host_virt_addr ||
	    length > ULONG_MAX - userspace_addr)
		return -EINVAL;

	pr_devel("dsm: hva %lx, length %lu, write %d\n", host_virt_addr, length,
		 write);
	idx = srcu_read_lock(&kvm->srcu);

	vfn_end = ((host_virt_addr + length - 1) >> PAGE_SHIFT) + 1;
	for (vfn = host_virt_addr >> PAGE_SHIFT; vfn < vfn_end; vfn += npages) {
		slot = vfn_to_hvaslot(kvm, vfn);
		/* for private memslots, do memcpy directly without DSM fetching */
		if (!slot) {
			npages = 1;
			goto do_memcpy;
		}
		npages =
			min(vfn_end - vfn, slot->base_vfn + slot->npages - vfn);

		mutex_lock(&kvm->arch.dsm_lock);
		for (i = 0; i < npages; i++)
			dsm_lock(kvm, slot, vfn + i, NULL);

		for (i = 0; i < npages; i += gfn_npages) {
			gfn = __kvm_dsm_vfn_to_gfn(slot, false, vfn + i,
						   &is_smm, NULL, NULL);
			memslot = __gfn_to_memslot(__kvm_memslots(kvm, is_smm),
						   gfn);
			gfn_npages =
				min(npages - i,
				    (unsigned long)(memslot->base_gfn +
						    memslot->npages - gfn));
			for (j = 0; j < gfn_npages; j++) {
				ret = kvm_dsm_page_fault(kvm, memslot, gfn + j,
							 is_smm, write);
				if (ret < 0)
					goto out_unlock;
			}
		}

do_memcpy:
		hva_start =
			max(host_virt_addr, (unsigned long)(vfn << PAGE_SHIFT));
		user_buf =
			(void *)(userspace_addr + hva_start - host_virt_addr);
		if (slot) {
			hva_end = min(
				host_virt_addr + length,
				(unsigned long)(slot->base_vfn + slot->npages)
					<< PAGE_SHIFT);
		} else {
			hva_end = min(host_virt_addr + length,
				      (unsigned long)(vfn + 1) << PAGE_SHIFT);
		}
		/*
		 * This is actually an user-to-user memcpy, but as we are sure that
		 * hva is valid, we can treat it as kernel memory.
		 */
		l = hva_end - hva_start;
		if (write)
			ret = __copy_from_user((void *)hva_start, user_buf, l);
		else
			ret = __copy_to_user(user_buf, (void *)hva_start, l);

		/* 复制可能部分成功；保守标记所有可能写入的页面，不能遗漏脏页。 */
		if (write && slot) {
			for (i = 0; i < npages; i++) {
				gfn = __kvm_dsm_vfn_to_gfn(slot, false, vfn + i,
							 &is_smm, NULL, NULL);
				memslot = __gfn_to_memslot(__kvm_memslots(kvm, is_smm), gfn);
				mark_page_dirty_in_slot(kvm, memslot, gfn);
			}
		}
		if (ret)
			ret = -EFAULT;
		if (!slot) {
			if (ret)
				goto out;
			continue;
		}

out_unlock:
		for (i = 0; i < npages; i++) {
			dsm_unlock_fast_path(slot, vfn + i, false);
			dsm_unlock(kvm, slot, vfn + i, NULL);
		}
		mutex_unlock(&kvm->arch.dsm_lock);
		if (ret < 0)
			goto out;
	}
out:
	srcu_read_unlock(&kvm->srcu, idx);
	return ret;
}

enum dsm_pin_transition {
	DSM_PIN_PREPARE,
	DSM_PIN_COMMIT,
	DSM_PIN_ABORT,
	DSM_PIN_RELEASE,
};

/* 有效引用包含暂存引用；解除操作只能消费已经提交的部分。 */
static noinline int kvm_dsm_pin_transition(struct kvm *kvm,
		struct kvm_dsm_memory_slot *slot, hfn_t vfn, bool write,
		enum dsm_pin_transition transition)
{
	struct kvm_dsm_info *info = &slot->vfn_dsm_state[vfn - slot->base_vfn];
	atomic_t *refs = write ? &info->pinned_write : &info->pinned_read;
	u32 *pending = write ? &info->pending_write : &info->pending_read;
	u64 *total = write ? &kvm->arch.dsm_write_pins : &kvm->arch.dsm_read_pins;
	unsigned long flags;
	int count, ret = 0;

	lockdep_assert_held(&kvm->arch.dsm_pin_refs_lock);
	spin_lock_irqsave(&kvm->arch.dsm_admission_lock, flags);
	count = atomic_read(refs);
	if (count < 0 || *pending > count) {
		ret = -EINVAL;
		goto out;
	}
	switch (transition) {
	case DSM_PIN_PREPARE:
		if (count == INT_MAX || *total == U64_MAX) {
			ret = -EOVERFLOW;
			break;
		}
		(*pending)++;
		atomic_inc(refs);
		(*total)++;
		break;
	case DSM_PIN_COMMIT:
		if (!*pending) {
			ret = -EINVAL;
			break;
		}
		(*pending)--;
		break;
	case DSM_PIN_ABORT:
		if (!*pending || !*total) {
			ret = -EINVAL;
			break;
		}
		(*pending)--;
		atomic_dec_return_release(refs);
		(*total)--;
		break;
	case DSM_PIN_RELEASE:
		if (count == *pending || !*total) {
			ret = -EINVAL;
			break;
		}
		atomic_dec_return_release(refs);
		(*total)--;
		break;
	}
out:
	spin_unlock_irqrestore(&kvm->arch.dsm_admission_lock, flags);
	return ret;
}

/* 整段解除只使用引用锁；不能等待取页线程持有的槽锁或页面锁。 */
static int kvm_dsm_unpin_range(struct kvm *kvm, hfn_t first, hfn_t end, bool write)
{
	struct kvm_dsm_memory_slot *slot;
	struct kvm_dsm_info *info;
	hfn_t vfn;
	int count, ret = 0;
	u32 pending;

	mutex_lock(&kvm->arch.dsm_pin_refs_lock);
	for (vfn = first; vfn < end; vfn++) {
		slot = vfn_to_hvaslot(kvm, vfn);
		if (!slot) {
			continue;
		}
		info = &slot->vfn_dsm_state[vfn - slot->base_vfn];
		count = atomic_read(write ? &info->pinned_write : &info->pinned_read);
		pending = write ? info->pending_write : info->pending_read;
		if (count <= 0 || pending >= count) {
			ret = -EINVAL;
			goto out;
		}
	}
	for (vfn = first; vfn < end; vfn++) {
		slot = vfn_to_hvaslot(kvm, vfn);
		if (!slot) {
			continue;
		}
		ret = kvm_dsm_pin_transition(kvm, slot, vfn, write, DSM_PIN_RELEASE);
		if (WARN_ON_ONCE(ret)) {
			break;
		}
	}
out:
	mutex_unlock(&kvm->arch.dsm_pin_refs_lock);
	return ret;
}

/* 调用者持有 slots_lock，固定期间不得删除、移动或重建任何内存槽。 */
bool kvm_dsm_has_pins(struct kvm *kvm)
{
	unsigned long flags;
	bool busy;

	lockdep_assert_held(&kvm->slots_lock);
	spin_lock_irqsave(&kvm->arch.dsm_admission_lock, flags);
	busy = kvm->arch.dsm_active_pin_ops || kvm->arch.dsm_read_pins ||
	       kvm->arch.dsm_write_pins;
	spin_unlock_irqrestore(&kvm->arch.dsm_admission_lock, flags);
	return busy;
}

static int kvm_dsm_pin_status(struct kvm *kvm, void __user *argp)
{
	struct kvm_dsm_pin_status status = { .version = 1 };
	unsigned long flags;

	spin_lock_irqsave(&kvm->arch.dsm_admission_lock, flags);
	status.active_ops = kvm->arch.dsm_active_pin_ops;
	status.read_refs = kvm->arch.dsm_read_pins;
	status.write_refs = kvm->arch.dsm_write_pins;
	status.error = READ_ONCE(kvm->arch.dsm_error);
	spin_unlock_irqrestore(&kvm->arch.dsm_admission_lock, flags);
	return copy_to_user(argp, &status, sizeof(status)) ? -EFAULT : 0;
}

static int kvm_dsm_mempin(struct kvm *kvm, unsigned long host_virt_addr,
			  unsigned long length, bool write, bool unpin)
{
	struct kvm_dsm_memory_slot *slot;
	struct kvm_memory_slot *memslot;
	hfn_t first, vfn, end, completed;
	gfn_t gfn;
	bool is_smm;
	int idx, ret = 0;
	enum dsm_pin_transition finish;

	if (current->mm != kvm->mm) {
		return -EFAULT;
	}
	if (!kvm->arch.dsm_enabled) {
		return -EINVAL;
	}
	if (!length) {
		return 0;
	}
	if (length > ULONG_MAX - host_virt_addr) {
		return -EINVAL;
	}
	/* 等先前的槽更新结束；本次准入令牌阻止后续更新，SRCU 保留对象存活。 */
	if (mutex_lock_killable(&kvm->slots_lock)) {
		return -EINTR;
	}
	idx = srcu_read_lock(&kvm->srcu);
	mutex_unlock(&kvm->slots_lock);
	first = host_virt_addr >> PAGE_SHIFT;
	end = ((host_virt_addr + length - 1) >> PAGE_SHIFT) + 1;
	if (unpin) {
		ret = kvm_dsm_unpin_range(kvm, first, end, write);
		goto out_srcu;
	}

	mutex_lock(&kvm->arch.dsm_lock);
	for (vfn = first; vfn < end; vfn++) {
		slot = vfn_to_hvaslot(kvm, vfn);
		if (!slot) {
			continue;
		}
		dsm_lock(kvm, slot, vfn, NULL);
		is_smm = false;
		gfn = __kvm_dsm_vfn_to_gfn(slot, false, vfn, &is_smm, NULL, NULL);
		memslot = __gfn_to_memslot(__kvm_memslots(kvm, is_smm), gfn);
		if (gfn == (gfn_t)-1 || !memslot) {
			ret = -EFAULT;
		} else {
			ret = kvm_dsm_page_fault(kvm, memslot, gfn, is_smm, write);
		}
		if (ret >= 0) {
			mutex_lock(&kvm->arch.dsm_pin_refs_lock);
			ret = kvm_dsm_pin_transition(kvm, slot, vfn, write, DSM_PIN_PREPARE);
			mutex_unlock(&kvm->arch.dsm_pin_refs_lock);
		}
		dsm_unlock_fast_path(slot, vfn, false);
		dsm_unlock(kvm, slot, vfn, NULL);
		if (ret < 0) {
			break;
		}
	}

	/* 整段成功后才允许外部解除；失败只撤销本操作尚未提交的引用。 */
	finish = ret < 0 ? DSM_PIN_ABORT : DSM_PIN_COMMIT;
	mutex_lock(&kvm->arch.dsm_pin_refs_lock);
	for (completed = first; completed < vfn; completed++) {
		slot = vfn_to_hvaslot(kvm, completed);
		if (!slot) {
			continue;
		}
		WARN_ON_ONCE(kvm_dsm_pin_transition(kvm, slot, completed, write, finish));
	}
	mutex_unlock(&kvm->arch.dsm_pin_refs_lock);
	mutex_unlock(&kvm->arch.dsm_lock);
out_srcu:
	srcu_read_unlock(&kvm->srcu, idx);
	return ret;
}

/* 普通 VM 也计数，避免与同一 VM 上正在执行的 DSM_ENABLE 竞态。 */
int kvm_dsm_ioctl_enter(struct kvm *kvm, unsigned int ioctl, bool vm_ioctl)
{
	unsigned long flags;
	int ret;

	if (vm_ioctl && (ioctl == KVM_DSM_IOCTL_DRAIN ||
			 ioctl == KVM_DSM_IOCTL_STATUS ||
			 ioctl == KVM_DSM_TRANSPORT_STATUS ||
			 ioctl == KVM_DSM_PIN_STATUS ||
			 ioctl == KVM_DSM_TRANSPORT_FENCE ||
			 ioctl == KVM_DSM_CLOSE))
		return 0;
	spin_lock_irqsave(&kvm->arch.dsm_admission_lock, flags);
	ret = READ_ONCE(kvm->arch.dsm_error);
	if (!ret && kvm->arch.dsm_ioctl_generation)
		ret = -ESHUTDOWN;
	if (!ret) {
		kvm->arch.dsm_active_ioctls++;
		ret = 1;
		/* 令牌二覆盖参数复制和等待槽锁，防止在固定调用尚未提交时封闭。 */
		if (vm_ioctl && ioctl == KVM_DSM_MEMPIN) {
			kvm->arch.dsm_active_pin_ops++;
			ret = 2;
		}
	}
	spin_unlock_irqrestore(&kvm->arch.dsm_admission_lock, flags);
	return ret;
}

void kvm_dsm_ioctl_leave(struct kvm *kvm, int token)
{
	unsigned long flags;

	if (!token)
		return;
	spin_lock_irqsave(&kvm->arch.dsm_admission_lock, flags);
	if (!WARN_ON_ONCE(!kvm->arch.dsm_active_ioctls)) {
		kvm->arch.dsm_active_ioctls--;
	}
	if (token == 2 && !WARN_ON_ONCE(!kvm->arch.dsm_active_pin_ops)) {
		kvm->arch.dsm_active_pin_ops--;
	}
	spin_unlock_irqrestore(&kvm->arch.dsm_admission_lock, flags);
	wake_up_all(&kvm->arch.dsm_ioctl_wait);
}

/* 超时和信号只结束本次等待，不能重新开放入口或取消先前已准入的事务。 */
static int kvm_dsm_ioctl_drain(struct kvm *kvm, void __user *argp)
{
	struct kvm_dsm_ioctl_drain params;
	unsigned long flags;
	long waited;
	int ret;

	if (copy_from_user(&params, argp, sizeof(params)))
		return -EFAULT;
	if (params.version != 1 || params.flags || !params.generation ||
	    !params.timeout_ms || params.timeout_ms > 30000 || params.reserved)
		return -EINVAL;
	/* 不等待管理锁，避免尚未封闭入口就陷入无期限等待；忙时可重试。 */
	if (!mutex_trylock(&kvm->lock))
		return -EBUSY;
	if (!kvm->arch.dsm_enabled) {
		mutex_unlock(&kvm->lock);
		return -EINVAL;
	}
	spin_lock_irqsave(&kvm->arch.dsm_admission_lock, flags);
	ret = READ_ONCE(kvm->arch.dsm_error);
	if (!ret && kvm->arch.dsm_ioctl_generation &&
	    kvm->arch.dsm_ioctl_generation != params.generation)
		ret = -ESTALE;
	/* 不封闭仍需 unpin 的 VM，也不让已准入的固定调用在检查后新增引用。 */
	if (!ret && (kvm->arch.dsm_active_pin_ops || kvm->arch.dsm_read_pins ||
		     kvm->arch.dsm_write_pins)) {
		ret = -EBUSY;
	}
	if (!ret) {
		kvm->arch.dsm_ioctl_generation = params.generation;
	}
	spin_unlock_irqrestore(&kvm->arch.dsm_admission_lock, flags);
	mutex_unlock(&kvm->lock);
	if (ret)
		return ret;

	waited = wait_event_killable_timeout(kvm->arch.dsm_ioctl_wait,
		!READ_ONCE(kvm->arch.dsm_active_ioctls) ||
		READ_ONCE(kvm->arch.dsm_error), msecs_to_jiffies(params.timeout_ms));
	spin_lock_irqsave(&kvm->arch.dsm_admission_lock, flags);
	ret = READ_ONCE(kvm->arch.dsm_error);
	if (!ret && waited < 0)
		ret = waited;
	if (!ret && kvm->arch.dsm_active_ioctls)
		ret = -ETIMEDOUT;
	spin_unlock_irqrestore(&kvm->arch.dsm_admission_lock, flags);
	return ret;
}

static int kvm_dsm_ioctl_status(struct kvm *kvm, void __user *argp)
{
	struct kvm_dsm_ioctl_status status = { .version = 1 };
	unsigned long flags;

	spin_lock_irqsave(&kvm->arch.dsm_admission_lock, flags);
	status.generation = kvm->arch.dsm_ioctl_generation;
	status.state = !!status.generation;
	status.active = kvm->arch.dsm_active_ioctls;
	status.error = READ_ONCE(kvm->arch.dsm_error);
	spin_unlock_irqrestore(&kvm->arch.dsm_admission_lock, flags);
	return copy_to_user(argp, &status, sizeof(status)) ? -EFAULT : 0;
}

/* 入站处理器和已准入调用都可发起反向请求，不依据 socket bank 再次限流。 */
int kvm_dsm_exchange_begin(struct kvm *kvm)
{
	unsigned long flags;
	int ret;

	spin_lock_irqsave(&kvm->arch.dsm_admission_lock, flags);
	ret = READ_ONCE(kvm->arch.dsm_error);
	if (!ret && READ_ONCE(kvm->arch.dsm_stopped))
		ret = -EPIPE;
	if (!ret && kvm->arch.dsm_transport_generation)
		ret = -ESHUTDOWN;
	if (!ret)
		kvm->arch.dsm_active_exchanges++;
	spin_unlock_irqrestore(&kvm->arch.dsm_admission_lock, flags);
	return ret;
}

static void dsm_counter_update(struct kvm *kvm, u32 *counter, bool add)
{
	unsigned long flags;

	spin_lock_irqsave(&kvm->arch.dsm_admission_lock, flags);
	if (add)
		(*counter)++;
	else if (!WARN_ON_ONCE(!*counter))
		(*counter)--;
	spin_unlock_irqrestore(&kvm->arch.dsm_admission_lock, flags);
	wake_up_all(&kvm->arch.dsm_ioctl_wait);
}

void kvm_dsm_exchange_done(struct kvm *kvm)
{
	dsm_counter_update(kvm, &kvm->arch.dsm_active_exchanges, false);
}

void kvm_dsm_cache_count(struct kvm *kvm, bool add)
{
	dsm_counter_update(kvm, &kvm->arch.dsm_cached_responses, add);
}

/* 页面准入与封闭共用锁；不能先放行请求，再检查独立的零计数快照。 */
int kvm_dsm_request_count(struct kvm *kvm, bool add)
{
	unsigned long flags;
	int ret = 0;

	spin_lock_irqsave(&kvm->arch.dsm_admission_lock, flags);
	if (add) {
		ret = READ_ONCE(kvm->arch.dsm_error);
		if (!ret && READ_ONCE(kvm->arch.dsm_stopped))
			ret = -EPIPE;
		if (!ret && kvm->arch.dsm_transport_generation)
			ret = -ESHUTDOWN;
		if (!ret)
			kvm->arch.dsm_active_requests++;
	} else if (!WARN_ON_ONCE(!kvm->arch.dsm_active_requests)) {
		kvm->arch.dsm_active_requests--;
	}
	spin_unlock_irqrestore(&kvm->arch.dsm_admission_lock, flags);
	wake_up_all(&kvm->arch.dsm_ioctl_wait);
	return ret;
}

static int kvm_dsm_transport_status(struct kvm *kvm, void __user *argp)
{
	struct kvm_dsm_transport_status status = { .version = 2 };
	unsigned long flags;

	spin_lock_irqsave(&kvm->arch.dsm_admission_lock, flags);
	status.exchanges = kvm->arch.dsm_active_exchanges;
	status.cached_responses = kvm->arch.dsm_cached_responses;
	status.inbound_requests = kvm->arch.dsm_active_requests;
	status.state = !!kvm->arch.dsm_transport_generation;
	status.generation = kvm->arch.dsm_transport_generation;
	status.error = READ_ONCE(kvm->arch.dsm_error);
	spin_unlock_irqrestore(&kvm->arch.dsm_admission_lock, flags);
	return copy_to_user(argp, &status, sizeof(status)) ? -EFAULT : 0;
}

/* 无锁条件只用来唤醒；成功判断和状态提交必须在下面的准入锁内重做。 */
static bool dsm_transport_idle(struct kvm *kvm)
{
	return !READ_ONCE(kvm->arch.dsm_active_ioctls) &&
	       !READ_ONCE(kvm->arch.dsm_active_pin_ops) &&
	       !READ_ONCE(kvm->arch.dsm_read_pins) &&
	       !READ_ONCE(kvm->arch.dsm_write_pins) &&
	       !READ_ONCE(kvm->arch.dsm_active_exchanges) &&
	       !READ_ONCE(kvm->arch.dsm_cached_responses) &&
	       !READ_ONCE(kvm->arch.dsm_active_requests);
}

/* 返回 EAGAIN 表示仍有真实工作；该路径不改变任何准入状态。 */
int dsm_transport_try_fence(struct kvm *kvm, u64 generation)
{
	unsigned long flags;
	int ret;

	spin_lock_irqsave(&kvm->arch.dsm_admission_lock, flags);
	ret = READ_ONCE(kvm->arch.dsm_error);
	if (!ret && READ_ONCE(kvm->arch.dsm_stopped))
		ret = -EPIPE;
	if (!ret && !kvm->arch.dsm_ioctl_generation)
		ret = -EPERM;
	if (!ret && kvm->arch.dsm_ioctl_generation != generation)
		ret = -ESTALE;
	if (!ret && !dsm_transport_idle(kvm))
		ret = -EAGAIN;
	if (!ret)
		kvm->arch.dsm_transport_generation = generation;
	spin_unlock_irqrestore(&kvm->arch.dsm_admission_lock, flags);
	return ret;
}

/* 超时或信号不封闭传输，已准入请求仍可完成反向调用和响应消费。 */
static int kvm_dsm_transport_fence(struct kvm *kvm, void __user *argp)
{
	struct kvm_dsm_ioctl_drain params;
	unsigned long deadline;
	long remaining;
	int ret;

	if (copy_from_user(&params, argp, sizeof(params)))
		return -EFAULT;
	if (params.version != 1 || params.flags || !params.generation ||
	    !params.timeout_ms || params.timeout_ms > 30000 || params.reserved)
		return -EINVAL;
	if (!READ_ONCE(kvm->arch.dsm_enabled))
		return -EINVAL;
	deadline = jiffies + msecs_to_jiffies(params.timeout_ms);
	for (;;) {
		ret = dsm_transport_try_fence(kvm, params.generation);
		if (ret != -EAGAIN)
			return ret;
		remaining = (long)(deadline - jiffies);
		if (remaining <= 0)
			return -ETIMEDOUT;
		remaining = wait_event_killable_timeout(kvm->arch.dsm_ioctl_wait,
			dsm_transport_idle(kvm) || READ_ONCE(kvm->arch.dsm_error) ||
			READ_ONCE(kvm->arch.dsm_stopped), remaining);
		if (remaining < 0)
			return remaining;
	}
}

long kvm_vm_ioctl_dsm(struct kvm *kvm, unsigned int ioctl, unsigned long arg)
{
	void __user *argp = (void __user *)arg;
	int r = -EFAULT;

	switch (ioctl) {
	case KVM_DSM_CLOSE:
		return dsm_close_ioctl(kvm, argp);
	case KVM_DSM_TRANSPORT_FENCE:
		return kvm_dsm_transport_fence(kvm, argp);
	case KVM_DSM_PIN_STATUS:
		return kvm_dsm_pin_status(kvm, argp);
	case KVM_DSM_TRANSPORT_STATUS:
		return kvm_dsm_transport_status(kvm, argp);
	case KVM_DSM_IOCTL_DRAIN:
		return kvm_dsm_ioctl_drain(kvm, argp);
	case KVM_DSM_IOCTL_STATUS:
		return kvm_dsm_ioctl_status(kvm, argp);
	case KVM_DSM_IPI: {
		struct kvm_dipi_params params;
		struct kvm_vcpu *vcpu = NULL;

		if (copy_from_user(&params, argp, sizeof(params)))
			goto out;

		vcpu = kvm_get_vcpu_by_id(kvm, params.vcpu_id);
		if (!vcpu || !lapic_in_kernel(vcpu)) {
			r = -EINVAL;
			break;
		}
		mutex_lock(&vcpu->mutex);
		vcpu_load(vcpu);
		r = kvm_lapic_reg_write_remote(vcpu->arch.apic, params.val,
					       params.val2, params.dest_id);
		vcpu_put(vcpu);
		mutex_unlock(&vcpu->mutex);
		break;
	}
	case KVM_DSM_X2APIC: {
		struct kvm_x2apic_params params;
		struct kvm_vcpu *vcpu = NULL;

		if (copy_from_user(&params, argp, sizeof(params)))
			goto out;

		vcpu = kvm_get_vcpu_by_id(kvm, params.vcpu_id);
		if (!vcpu || !lapic_in_kernel(vcpu)) {
			r = -EINVAL;
			break;
		}
		mutex_lock(&vcpu->mutex);
		vcpu_load(vcpu);
		r = kvm_x2apic_icr_write_fast(vcpu->arch.apic, params.data);
		vcpu_put(vcpu);
		mutex_unlock(&vcpu->mutex);
		break;
	}
	case KVM_DSM_APIC_BASE: {
		struct kvm_apic_base_params params;
		struct kvm_vcpu *vcpu = NULL;

		if (copy_from_user(&params, argp, sizeof(params)))
			goto out;

		vcpu = kvm_get_vcpu_by_id(kvm, params.vcpu_id);
		if (!vcpu || !lapic_in_kernel(vcpu)) {
			r = -EINVAL;
			break;
		}
		mutex_lock(&vcpu->mutex);
		vcpu_load(vcpu);
		r = kvm_apic_set_base(vcpu, params.data, params.host);
		vcpu_put(vcpu);
		mutex_unlock(&vcpu->mutex);
		break;
	}
	case KVM_DSM_ENABLE: {
		struct kvm_dsm_params params;

		r = -EFAULT;
		if (copy_from_user(&params, argp, sizeof(params)))
			goto out;

		mutex_lock(&kvm->lock);
		r = kvm_dsm_init(kvm, &params);
		mutex_unlock(&kvm->lock);
		if (r)
			goto out;
		break;
	}
	case KVM_DSM_MEMCPY: {
		struct kvm_dsm_memcpy cpy;

		r = -EFAULT;
		if (copy_from_user(&cpy, argp, sizeof(cpy)))
			goto out;
		r = kvm_dsm_memcpy(kvm, cpy.host_virt_addr, cpy.userspace_addr,
				   cpy.length, cpy.write);
		if (r)
			goto out;
		break;
	}
	case KVM_DSM_MEMPIN: {
		struct kvm_dsm_mempin pin;

		r = -EFAULT;
		if (copy_from_user(&pin, argp, sizeof(pin)))
			goto out;
		r = kvm_dsm_mempin(kvm, pin.host_virt_addr, pin.length,
				   pin.write, pin.unpin);
		if (r)
			goto out;
		break;
	}
	default:
		r = -ENOTTY;
		break;
	}
out:
	return r;
}
