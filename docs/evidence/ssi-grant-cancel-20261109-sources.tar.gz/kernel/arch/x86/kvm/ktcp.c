// SPDX-License-Identifier: GPL-2.0
/*
 * TCP support for KVM software distributed memory
 *
 * This feature allows us to run multiple KVM instances on different machines
 * sharing the same address space.
 *
 * Copyright (C) 2019-2026, Trusted Cloud Group, Institute of Scalable Computing,
 * Shanghai Jiao Tong University.
 *
 * Authors:
 *   Chen Yubin <binsschen@sjtu.edu.cn>
 *   Ding Zhuocheng <tcbbd@sjtu.edu.cn>
 *   Zhang Jin <jzhang3002@sjtu.edu.cn>
 *   Yu Boshi <201608ybs@sjtu.edu.cn>
 *
 * This work is licensed under the terms of the GNU GPL, version 2.  See
 * the COPYING file in the top-level directory.
 */

#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/init.h>

#include <linux/kthread.h>
#include <linux/net.h>
#include <linux/inet.h>
#include <net/sock.h>
#include <linux/tcp.h>
#include <linux/in.h>
#include <linux/uaccess.h>
#include <linux/socket.h>
#include <linux/slab.h>
#include <linux/sched/signal.h>
#include <linux/delay.h>
#include <linux/kvm_host.h>

#include "ktcp.h"
#include "dsm-util.h"
#include <linux/idr.h>

struct ktcp_hdr {
	size_t length;
	tx_add_t tx_add;
} __packed;

struct ktcp_cb {
	struct mutex slock; /* protects send buffer */
	struct mutex rlock; /* protects recv buffer */
	struct idr transactions;
	struct socket *socket;
	/* 不依赖收发锁，故障线程可以唤醒持锁的网络等待者。 */
	int error;
	bool connected;
	wait_queue_head_t connect_wait;
};

#define KTCP_BUFFER_SIZE (sizeof(struct ktcp_hdr) + PAGE_SIZE)

/* 锁存首个错误；shutdown 唤醒收发，但 socket 仍由原生命周期释放。 */
int ktcp_abort(struct ktcp_cb *cb, int error)
{
	int first;

	if (WARN_ON_ONCE(error >= 0))
		error = -EIO;
	first = cmpxchg(&cb->error, 0, error);
	/* 发布与非阻塞 connect 可交错，再次取消也必须关闭实际 socket。 */
	kernel_sock_shutdown(cb->socket, SHUT_RDWR);
	wake_up_all(&cb->connect_wait);
	return first ?: error;
}

/* 只在根线程收尽已接受队列后停止监听；已接受 socket 保留至握手完成。 */
int ktcp_shutdown_listener(struct ktcp_cb *cb)
{
	return kernel_sock_shutdown(cb->socket, SHUT_RD);
}

int ktcp_shutdown_write(struct ktcp_cb *cb)
{
	int ret = READ_ONCE(cb->error);

	return ret ?: kernel_sock_shutdown(cb->socket, SHUT_WR);
}

/* 首个建连者发布后其他取页线程也能看到对象，但不能在连接完成前发帧。 */
static int ktcp_wait_connected(struct ktcp_cb *cb)
{
	int ret = wait_event_killable(cb->connect_wait,
		READ_ONCE(cb->connected) || READ_ONCE(cb->error));

	return READ_ONCE(cb->error) ?: ret;
}

static bool ktcp_should_stop(void)
{
	return fatal_signal_pending(current) ||
	       ((current->flags & PF_KTHREAD) && kthread_should_stop());
}

static int __ktcp_send(struct socket *sock, const char *buffer, size_t length,
		       unsigned long flags)
{
	struct kvec vec;
	int len, written = 0, left = length;
	struct msghdr msg = {
		.msg_name = 0,
		.msg_namelen = 0,
		.msg_control = NULL,
		.msg_controllen = 0,
		.msg_flags = flags,
	};

repeat_send:
	if (ktcp_should_stop())
		return -EINTR;

	vec.iov_len = left;
	vec.iov_base = (char *)buffer + written;

	len = kernel_sendmsg(sock, &msg, &vec, 1, left);
	if (len == -EAGAIN || len == -ERESTARTSYS)
		goto repeat_send;
	if (len > 0) {
		written += len;
		left -= len;
		if (left != 0)
			goto repeat_send;
	}

	/* 已发送部分帧后出现错误，不能把正数短写伪装为完整请求。 */
	if (left)
		return len < 0 ? len : -ECONNRESET;
	return written;
}

int ktcp_send(struct ktcp_cb *cb, const char *buffer, size_t length,
	      unsigned long flags, const tx_add_t *tx_add)
{
	int ret;
	struct ktcp_hdr hdr;
	char *local_buffer;

	if (length > PAGE_SIZE)
		return -EMSGSIZE;
	ret = READ_ONCE(cb->error);
	if (ret)
		return ret;
	if (mutex_lock_killable(&cb->slock))
		return ktcp_abort(cb, -EINTR);
	ret = READ_ONCE(cb->error);
	if (ret) {
		mutex_unlock(&cb->slock);
		return ret;
	}
	hdr.tx_add = *tx_add;
	hdr.length = sizeof(hdr) + length;
	/* 固定帧的未使用尾部必须清零，不能把旧堆内容发送给对端。 */
	local_buffer = kzalloc(KTCP_BUFFER_SIZE, GFP_KERNEL);
	if (!local_buffer) {
		mutex_unlock(&cb->slock);
		return -ENOMEM;
	}
	memcpy(local_buffer, &hdr, sizeof(hdr));
	memcpy(local_buffer + sizeof(hdr), buffer, length);
	ret = __ktcp_send(cb->socket, local_buffer, KTCP_BUFFER_SIZE, flags);
	if (ret < 0)
		ret = ktcp_abort(cb, ret);
	else if (READ_ONCE(cb->error))
		ret = READ_ONCE(cb->error);
	kfree(local_buffer);
	mutex_unlock(&cb->slock);
	return ret < 0 ? ret : hdr.length;
}

/* 每条连接只给尚未结束的事务分配编号；跳过任意请求接收器使用的 0xff。 */
int ktcp_begin_transaction(struct ktcp_cb *cb, struct kvm *kvm,
			   struct ktcp_transaction *tx)
{
	int id, ret;

	ret = ktcp_wait_connected(cb);
	if (ret) {
		return ret;
	}
	memset(tx, 0, sizeof(*tx));
	if (mutex_lock_killable(&cb->rlock))
		return ktcp_abort(cb, -EINTR);
	ret = READ_ONCE(cb->error);
	if (ret)
		goto out;
	id = idr_alloc_cyclic(&cb->transactions, tx, 0, 65536, GFP_KERNEL);
	if (id == 0xff) {
		/* 暂时占住保留编号再分配，耗尽时返回 ENOSPC，不能循环重取 0xff。 */
		id = idr_alloc_cyclic(&cb->transactions, tx, 0, 65536, GFP_KERNEL);
		idr_remove(&cb->transactions, 0xff);
	}
	ret = id < 0 ? id : 0;
	if (!ret) {
		tx->kvm = kvm;
		tx->id = id;
	}
out:
	mutex_unlock(&cb->rlock);
	return ret;
}

/* 故障时也由原事务调用方清理缓存；释放缓存不等于成功消费响应。 */
void ktcp_end_transaction(struct ktcp_cb *cb, struct ktcp_transaction *tx)
{
	mutex_lock(&cb->rlock);
	WARN_ON_ONCE(idr_remove(&cb->transactions, tx->id) != tx);
	if (tx->response) {
		kfree(tx->response);
		tx->response = NULL;
		kvm_dsm_cache_count(tx->kvm, false);
	}
	mutex_unlock(&cb->rlock);
}

static int build_ktcp_recv_output(void *frame, char *buffer,
				  size_t capacity, tx_add_t *tx_add)
{
	size_t real_length;
	struct ktcp_hdr hdr;

	memcpy(&hdr, frame, sizeof(hdr));
	real_length = hdr.length - sizeof(hdr);
	/* 即使由其他接收者缓存，复制前仍检查本事务实际的目标容量。 */
	if (real_length > capacity) {
		kfree(frame);
		return -EMSGSIZE;
	}
	memcpy(buffer, (char *)frame + sizeof(hdr), real_length);
	*tx_add = hdr.tx_add;
	kfree(frame);
	return real_length;
}

static int __ktcp_receive(struct socket *sock, char *buffer,
			  size_t expected_size, bool nonblock)
{
	struct kvec vec;
	int ret;
	int len = 0;
	int recv_flags;

	struct msghdr msg = {
		.msg_name = 0,
		.msg_namelen = 0,
		.msg_control = NULL,
		.msg_controllen = 0,
		.msg_flags = 0,
	};

	if (expected_size == 0)
		return 0;

read_again:
	if (ktcp_should_stop())
		return -EINTR;

	vec.iov_len = expected_size - len;
	vec.iov_base = buffer + len;
	/* 首字节可非阻塞轮询；帧已开始后由当前读者等待余下字节。 */
	recv_flags = nonblock && len == 0 ? MSG_DONTWAIT : 0;
	ret = kernel_recvmsg(sock, &msg, &vec, 1, expected_size - len,
			     recv_flags);

	if (ret == 0) {
		return len ? -ECONNRESET : KTCP_EOF;
	}

	/* 让外层释放接收锁并退避，避免多事务之间互相阻塞。 */
	if (len == 0 && nonblock &&
	    (ret == -EWOULDBLOCK || ret == -EAGAIN)) {
		return ret;
	}

	if (ret == -EAGAIN || ret == -ERESTARTSYS) {
		goto read_again;
	} else if (ret < 0) {
		pr_err("kernel_recvmsg %d\n", ret);
		return ret;
	}
	len += ret;
	if (len != expected_size)
		goto read_again;

	return len;
}

int ktcp_receive(struct ktcp_cb *cb, char *buffer, size_t capacity,
		 unsigned long flags, tx_add_t *tx_add)
{
	struct ktcp_hdr hdr;
	int ret;
	struct ktcp_transaction *tx, *target;
	u32 usec_sleep = 0;
	char *local_buffer;

	if (WARN_ON_ONCE(!cb || !buffer || !tx_add))
		return -EINVAL;

	if (mutex_lock_killable(&cb->rlock))
		return ktcp_abort(cb, -EINTR);
repoll:
	ret = READ_ONCE(cb->error);
	if (ret)
		goto out;
	if (ktcp_should_stop()) {
		ret = -EINTR;
		goto out;
	}
	tx = NULL;
	if (tx_add->txid != 0xff) {
		tx = idr_find(&cb->transactions, tx_add->txid);
		if (!tx) {
			ret = -EPROTO;
			goto out;
		}
		if (tx->response) {
			local_buffer = tx->response;
			tx->response = NULL;
			ret = build_ktcp_recv_output(local_buffer, buffer, capacity, tx_add);
			kvm_dsm_cache_count(tx->kvm, false);
			goto out;
		}
		if (tx->received) {
			ret = -EPROTO;
			goto out;
		}
	}
	local_buffer = kmalloc(KTCP_BUFFER_SIZE, GFP_KERNEL);
	if (!local_buffer) {
		ret = -ENOMEM;
		goto out;
	}
	/* 任意请求接收者可睡眠；指定事务必须持续让出锁给其他读者。 */
	ret = __ktcp_receive(cb->socket, local_buffer, KTCP_BUFFER_SIZE,
			     tx_add->txid != 0xFF || (flags & SOCK_NONBLOCK));
	if (ret < 0) {
		if (ret == -EAGAIN) {
			kfree(local_buffer);
			mutex_unlock(&cb->rlock);
			usec_sleep = (usec_sleep + 1) > 1000 ? 1000 :
							       (usec_sleep + 1);
			usleep_range(usec_sleep, usec_sleep + 1);
			if (mutex_lock_killable(&cb->rlock))
				return ktcp_abort(cb, -EINTR);
			goto repoll;
		}
		kfree(local_buffer);
		if (ret == KTCP_EOF && (flags & KTCP_ALLOW_EOF)) {
			goto out;
		}
		if (ret == KTCP_EOF) {
			ret = -ECONNRESET;
		}
		pr_err("%s: __ktcp_receive error, ret %d\n", __func__, ret);
		goto out;
	}
	ret = READ_ONCE(cb->error);
	if (ret) {
		kfree(local_buffer);
		goto out;
	}
	usec_sleep = 0;
	memcpy(&hdr, local_buffer, sizeof(hdr));
	if (hdr.length < sizeof(hdr) || hdr.length > KTCP_BUFFER_SIZE) {
		kfree(local_buffer);
		ret = -EPROTO;
		goto out;
	}
	if (tx) {
		target = idr_find(&cb->transactions, hdr.tx_add.txid);
		/* 未登记、重复或已结束事务的响应不能留在缓存中等待未来编号复用。 */
		if (!target || target->received) {
			kfree(local_buffer);
			ret = -EPROTO;
			goto out;
		}
		target->received = true;
		if (target != tx) {
			target->response = local_buffer;
			kvm_dsm_cache_count(target->kvm, true);
			goto repoll;
		}
	}
	ret = build_ktcp_recv_output(local_buffer, buffer, capacity, tx_add);
out:
	if (ret < 0 && ret != KTCP_EOF)
		ret = ktcp_abort(cb, ret);
	mutex_unlock(&cb->rlock);
	return ret;
}

static int ktcp_create_cb(struct ktcp_cb **cbp)
{
	struct ktcp_cb *cb = kzalloc(sizeof(*cb), GFP_KERNEL);

	if (!cb)
		return -ENOMEM;
	mutex_init(&cb->slock);
	mutex_init(&cb->rlock);
	idr_init(&cb->transactions);
	init_waitqueue_head(&cb->connect_wait);
	*cbp = cb;
	return 0;
}

/* 先发布可取消的 socket；非阻塞建连不能躲过根线程的故障扫描。 */
int ktcp_connect(struct kvm *kvm, const char *host, u16 port, struct ktcp_cb **conn_cb)
{
	struct sockaddr_in saddr = {};
	struct ktcp_cb *cb;
	struct socket *sock;
	int ret;

	if (!host || !conn_cb) {
		return -EINVAL;
	}
	ret = ktcp_create_cb(&cb);
	if (ret) {
		return ret;
	}
	ret = sock_create(PF_INET, SOCK_STREAM, IPPROTO_TCP, &sock);
	if (ret) {
		kfree(cb);
		return ret;
	}
	cb->socket = sock;
	smp_store_release(conn_cb, cb);
	saddr.sin_family = AF_INET;
	saddr.sin_port = htons(port);
	saddr.sin_addr.s_addr = in_aton(host);
	ret = READ_ONCE(kvm->arch.dsm_error);
	if (!ret && READ_ONCE(kvm->arch.dsm_stopped)) {
		ret = -EPIPE;
	}
	if (ret) {
		return ktcp_abort(cb, ret);
	}
	ret = sock->ops->connect(sock, (struct sockaddr_unsized *)&saddr,
				sizeof(saddr), O_NONBLOCK);
	if (ret && ret != -EINPROGRESS) {
		return ktcp_abort(cb, ret);
	}
	for (;;) {
		ret = READ_ONCE(cb->error) ?: READ_ONCE(kvm->arch.dsm_error);
		if (!ret && (ktcp_should_stop() || READ_ONCE(kvm->arch.dsm_stopped))) {
			ret = -EINTR;
		}
		if (!ret && READ_ONCE(sock->sk->sk_err)) {
			ret = -READ_ONCE(sock->sk->sk_err);
		}
		if (ret) {
			return ktcp_abort(cb, ret);
		}
		if (READ_ONCE(sock->sk->sk_state) == TCP_ESTABLISHED) {
			WRITE_ONCE(cb->connected, true);
			wake_up_all(&cb->connect_wait);
			return 0;
		}
		if (READ_ONCE(sock->sk->sk_state) == TCP_CLOSE) {
			return ktcp_abort(cb, -ECONNREFUSED);
		}
		wait_event_interruptible_timeout(*sk_sleep(sock->sk),
			READ_ONCE(sock->sk->sk_state) != TCP_SYN_SENT ||
			READ_ONCE(cb->error), msecs_to_jiffies(10));
	}
}

int ktcp_listen(const char *host, u16 port, struct ktcp_cb **listen_cb)
{
	int ret;
	struct sockaddr_in saddr = {};
	struct ktcp_cb *cb;
	struct socket *listen_socket;

	ret = ktcp_create_cb(&cb);
	if (ret)
		return ret;
	ret = sock_create(PF_INET, SOCK_STREAM, IPPROTO_TCP, &listen_socket);
	if (ret)
		goto out_cb;
	saddr.sin_family = AF_INET;
	saddr.sin_port = htons(port);
	saddr.sin_addr.s_addr = in_aton(host);
	ret = listen_socket->ops->bind(listen_socket,
				       (struct sockaddr_unsized *)&saddr,
				       sizeof(saddr));
	if (ret) {
		pr_err("%s: bind failed, return %d\n", __func__, ret);
		goto out_socket;
	}
	ret = listen_socket->ops->listen(listen_socket, DEFAULT_BACKLOG);
	if (ret) {
		pr_err("%s: listen failed, return %d\n", __func__, ret);
		goto out_socket;
	}
	cb->socket = listen_socket;
	*listen_cb = cb;
	return 0;
out_socket:
	sock_release(listen_socket);
out_cb:
	kfree(cb);
	return ret;
}

int ktcp_accept(struct ktcp_cb *listen_cb, struct ktcp_cb **accept_cb,
		unsigned long flag)
{
	int ret;
	struct ktcp_cb *cb;
	struct socket *listen_socket, *accept_socket;
	struct proto_accept_arg arg = { .flags = flag, .kern = false };

	if (!listen_cb || !listen_cb->socket)
		return -EINVAL;
	listen_socket = listen_cb->socket;
	ret = ktcp_create_cb(&cb);
	if (ret)
		return ret;
	ret = sock_create_lite(listen_socket->sk->sk_family,
			       listen_socket->sk->sk_type,
			       listen_socket->sk->sk_protocol, &accept_socket);
	if (ret)
		goto out_cb;
re_accept:
	ret = READ_ONCE(listen_cb->error);
	if (ret)
		goto out_socket;
	ret = listen_socket->ops->accept(listen_socket, accept_socket, &arg);
	if (ret == -ERESTARTSYS && !ktcp_should_stop())
		goto re_accept;
	if (ret)
		goto out_socket;
	accept_socket->ops = listen_socket->ops;
	ret = READ_ONCE(listen_cb->error);
	if (ret)
		goto out_socket;
	cb->socket = accept_socket;
	cb->connected = true;
	*accept_cb = cb;
	return 0;
out_socket:
	sock_release(accept_socket);
out_cb:
	kfree(cb);
	return ret;
}

int ktcp_release(struct ktcp_cb *conn_cb)
{
	if (!conn_cb)
		return -EINVAL;
	/* 连接销毁前所有 fetch 必须已结束，响应缓存由各事务清理。 */
	WARN_ON_ONCE(!idr_is_empty(&conn_cb->transactions));
	idr_destroy(&conn_cb->transactions);
	sock_release(conn_cb->socket);
	kfree(conn_cb);
	return 0;
}
