from pathlib import Path
import argparse,hashlib,json,shlex,subprocess,tarfile,time,io,shutil
w=Path(__file__).resolve().parent
repo=Path('/Users/zjarlin/projects/sshpool')
p=argparse.ArgumentParser();p.add_argument('label');p.add_argument('mode');p.add_argument('--grace',type=int,default=1000);a=p.parse_args()
assert a.mode in ('control','handler','root','reset') and a.grace in (0,1000)
assert all(c in 'abcdefghijklmnopqrstuvwxyz0123456789-' for c in a.label)
row=json.loads((w/'boot.json').read_text())[0]
base=['ssh','-F',str(w/'guest_ssh_config'),'-o','BatchMode=yes','-o','ConnectTimeout=8','-o','ServerAliveInterval=15','-o','ServerAliveCountMax=3','ssi-lab-1']
def read(cmd,**kw):return subprocess.check_output(base+[cmd],timeout=30,**kw)
assert read('cat /etc/machine-id; uname -r').decode().splitlines()==[row['machine_id'],row['kernel']]
assert read('sha256sum /home/ubuntu/ssi/probe-grant-atomic').decode().split()[0]==json.loads((w/'probe-build.json').read_text())['binary_sha256']
assert not read('sudo cat /sys/kernel/tracing/kprobe_events; sudo find /sys/kernel/tracing/instances -mindepth 1 -maxdepth 1').strip()
assert not [x for x in read('ps -eo comm=').decode().splitlines() if x.startswith(('probe-grant','dsm-conn/','kvm-dsm/','qemu-system-'))]
ports=' or '.join(f'{side} = :{port}' for side in ('sport','dport') for port in (37710,37711,40000,40001))
deadline=time.monotonic()+150
while read(f"ss -H -tan '( {ports} )'").strip():
 if time.monotonic()>deadline:raise RuntimeError('TCP did not drain')
 time.sleep(2)
local=w/a.label;local.mkdir()
remote='/run/sshpool-grant-cancel/'+a.label
names=('probe-grant-cancel.py','probe-request-safety.py','probe-request-cancel.py','probe-receive.py','trace-teardown.py')
for name in names:shutil.copy2(repo/'scripts/ssi-lab'/name,local/name)
(local/'source-hashes.json').write_text(json.dumps({name:hashlib.sha256((local/name).read_bytes()).hexdigest() for name in names},indent=2)+'\n')
data=io.BytesIO()
with tarfile.open(fileobj=data,mode='w') as tar:
 for name in names:tar.add(local/name,arcname=name)
read('sudo mkdir -p /run/sshpool-grant-cancel && sudo mkdir '+remote+' && sudo tar -xf - -C '+remote,input=data.getvalue())
chain='sudo nft -j -a list chain inet sshpool_ssi_lab input'
before=json.loads(read(chain));comment='sshpool-grant-cancel'
assert before==json.loads((w/'node0-before-firewall.json').read_text())
cursor=read('sudo journalctl -k -b -n 0 --show-cursor --no-pager').decode().split('-- cursor: ')[1].strip()
status=None
try:
 rule=''.join('insert rule inet sshpool_ssi_lab input iifname "lo" ip saddr 127.0.0.0/8 tcp '+side+' { 37710, 37711 } accept comment "'+comment+'"\n' for side in ('dport','sport'))
 read('sudo nft -f -',input=rule.encode())
 (local/'firewall-active.json').write_bytes(read(chain))
 command=['sudo','python3',remote+'/probe-grant-cancel.py','--worker','/home/ubuntu/ssi/probe-grant-atomic','--require-kernel',row['kernel'],'--mode',a.mode,'--grace',str(a.grace),'--output',remote+'/result.json']
 with (local/'stdout.log').open('xb') as out,(local/'stderr.log').open('xb') as err:
  status=subprocess.run(base+[shlex.join(command)],stdout=out,stderr=err).returncode
finally:
 current=json.loads(read(chain))
 for item in current['nftables']:
  r=item.get('rule',{})
  if r.get('comment')==comment:read('sudo nft delete rule inet sshpool_ssi_lab input handle '+str(r['handle']))
 after=json.loads(read(chain));assert after==before
 (local/'firewall.json').write_text(json.dumps({'before':before,'after':after,'restored_exactly':True},indent=2)+'\n')
 capture=subprocess.run(base+['sudo cat '+remote+'/result.json'],capture_output=True,timeout=30)
 if capture.returncode==0:(local/'result.json').write_bytes(capture.stdout)
 (local/'host.log').write_bytes(read('sudo journalctl -k -b --no-pager --after-cursor='+shlex.quote(cursor)))
 (local/'runner.json').write_text(json.dumps({'exit':status,'capture_exit':capture.returncode,'node':row,'mode':a.mode,'grace':a.grace},indent=2)+'\n')
print(a.label,status,flush=True)
print((local/'stdout.log').read_text(),flush=True)
print((local/'stderr.log').read_text(),flush=True)
