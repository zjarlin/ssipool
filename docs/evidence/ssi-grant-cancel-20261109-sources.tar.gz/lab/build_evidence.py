from pathlib import Path
import gzip,hashlib,importlib.util,io,json,tarfile
w=Path(__file__).resolve().parent;repo=Path('/Users/zjarlin/projects/sshpool');out=repo/'docs/evidence';stem='ssi-grant-cancel-20261109'
spec=importlib.util.spec_from_file_location('checker',repo/'scripts/ssi-lab/check-grant-cancel.py');checker=importlib.util.module_from_spec(spec);spec.loader.exec_module(checker)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def put(name,raw):
 packed=gzip.compress(raw,mtime=0);(out/name).write_bytes(packed)
 return {'file':name,'bytes':len(packed),'sha256':sha(packed),'raw_sha256':sha(raw)}
manifest={'kernel':'7.1.0-rc3-sshpool-gvm-pf30','kernel_sha256':json.loads((w/'boot.json').read_text())[0]['kernel_sha256'],'probe_build':json.loads((w/'probe-build.json').read_text()),'runs':[],'rejected':[],'goal_complete':False,'full_ssi_accepted':False,'native_close_accepted':False}
files={}
for directory in sorted(w.iterdir()):
 if not directory.is_dir() or not (directory/'result.json').exists():continue
 label=directory.name;probe=json.loads((directory/'result.json').read_text())
 bundle={'probe':probe,'runner':json.loads((directory/'runner.json').read_text()),'firewall':json.loads((directory/'firewall.json').read_text()),'host_log':(directory/'host.log').read_text(),'source_hashes':json.loads((directory/'source-hashes.json').read_text())}
 record={'label':label,'archive':put(stem+'-'+label+'.json.gz',(json.dumps(bundle,indent=2)+'\n').encode())}
 try:record['analysis']=checker.inspect(probe);manifest['runs'].append(record)
 except (ValueError,KeyError) as error:record.update(accepted=False,reason=str(error));manifest['rejected'].append(record)
 for p in directory.glob('*.py'):files['attempts/'+label+'/'+p.name]=p.read_bytes()
 for name in ('stdout.log','stderr.log','firewall-active.json'):
  files['attempts/'+label+'/'+name]=(directory/name).read_bytes()
for name in ('probe-grant-cancel.py','check-grant-cancel.py','probe-write-grant.c','probe-request-safety.py','probe-request-cancel.py','probe-receive.py','trace-teardown.py'):
 files[name]=(repo/'scripts/ssi-lab'/name).read_bytes()
for name in ('build_evidence.py','run_probe.py','boot_pf30.py','restore_lab.py','probe-build.json','compiled-source-hashes.json','nodes.json','boot.json','node0-before-boot.sha256','node0-before-grub.cfg','node0-before-firewall.json','node0-entry','node0-grub.cfg'):
 files['lab/'+name]=(w/name).read_bytes()
for p in (w/'kernel').rglob('*'):
 if p.is_file():files[str(p.relative_to(w))]=p.read_bytes()
for name in ('restoration.json','node1-final.json'):
 if (w/name).exists():manifest[name.removesuffix('.json')]=json.loads((w/name).read_text())
raw=io.BytesIO()
with tarfile.open(fileobj=raw,mode='w') as tar:
 for name,data in sorted(files.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
manifest['sources']=put(stem+'-sources.tar.gz',raw.getvalue());manifest['sources']['members']={name:sha(data) for name,data in sorted(files.items())}
(out/(stem+'.json')).write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'accepted':[x['label'] for x in manifest['runs']],'rejected':[(x['label'],x['reason']) for x in manifest['rejected']]},ensure_ascii=False))
